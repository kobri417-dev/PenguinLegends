extends Node3D

# Penguin Legends 3D — Android-friendly procedural adventure prototype.
# Godot 4.3 / GL Compatibility. No external assets or plugins required.

const SAVE_PATH := "user://penguin_legends_save.cfg"
const MAX_LEVEL := 200
const GRAVITY := 20.0

var level := 1
var coins := 0
var lives := 3
var health := 100
var player: CharacterBody3D
var camera: Camera3D
var world_root: Node3D
var hud: CanvasLayer
var level_label: Label
var stats_label: Label
var message_label: Label
var boss_label: Label
var jump_requested := false
var attack_requested := false
var special_requested := false
var tilt_axis := 0.0
var touch_move_axis := 0.0
var left_move_pressed := false
var right_move_pressed := false
var attack_cooldown := 0.0
var special_cooldown := 0.0
var invulnerable := 0.0
var boss: Node3D
var boss_hp := 0
var boss_max_hp := 0
var boss_active := false
var game_over := false
var elapsed := 0.0
var enemies: Array[Node3D] = []
var coins_in_world: Array[Area3D] = []
var mobile := false
var menu_layer: CanvasLayer
var menu_root: Control
var music_player: AudioStreamPlayer
var intro_player: AudioStreamPlayer
var selected_penguin := 0
var music_enabled := true
var menu_open := true
var penguin_colors := [Color(0.025, 0.055, 0.095), Color(0.12, 0.35, 0.78), Color(0.35, 0.10, 0.48)]
var penguin_names := ["KOBRA CLASSIC", "ARCTIC GUARDIAN", "SHADOW LEGEND"]
var menu_trees: Array[Node3D] = []
var snow_particles: GPUParticles3D

func _ready() -> void:
	mobile = OS.has_feature("android") or OS.has_feature("ios")
	load_progress()
	_setup_audio()
	_build_menu_background()
	_show_intro()
	_build_main_menu()

func _setup_audio() -> void:
	music_player = AudioStreamPlayer.new()
	music_player.name = "BackgroundMusic"
	music_player.volume_db = -15.0
	music_player.stream = _make_music_stream()
	add_child(music_player)
	intro_player = AudioStreamPlayer.new()
	intro_player.name = "KobratixIntroAudio"
	intro_player.volume_db = -8.0
	intro_player.stream = _make_intro_stream()
	add_child(intro_player)
	music_player.play()

func _make_music_stream() -> AudioStreamWAV:
	# Original procedural chiptune-style ambient loop; no external files needed.
	var rate := 22050
	var seconds := 8.0
	var bytes := PackedByteArray()
	var frames := int(rate * seconds)
	for i in range(frames):
		var t := float(i) / float(rate)
		var beat := int(t * 2.0) % 4
		var roots := [110.0, 130.81, 146.83, 98.0]
		var root: float = roots[int(t / 2.0) % roots.size()]
		var bass := sin(TAU * root * t) * 0.20
		var pad := sin(TAU * root * 2.0 * t) * 0.10 + sin(TAU * root * 3.0 * t) * 0.045
		var note := 0.0
		if beat == 0 or beat == 2:
			note = sin(TAU * root * 4.0 * t) * 0.06
		var fade := minf(1.0, t * 8.0) * minf(1.0, (seconds - t) * 8.0)
		var sample := int(clampf((bass + pad + note) * fade, -0.9, 0.9) * 32767.0)
		bytes.append(sample & 0xff)
		bytes.append((sample >> 8) & 0xff)
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.stereo = false
	stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	stream.loop_begin = 0
	stream.loop_end = frames
	stream.data = bytes
	return stream

func _make_intro_stream() -> AudioStreamWAV:
	# Short synthesized rising fanfare for the creator splash.
	var rate := 22050
	var seconds := 1.7
	var bytes := PackedByteArray()
	var frames := int(rate * seconds)
	for i in range(frames):
		var t := float(i) / float(rate)
		var freq := 330.0 + 330.0 * (t / seconds)
		var env := minf(1.0, t * 12.0) * maxf(0.0, 1.0 - t / seconds)
		var sample := int(clampf(sin(TAU * freq * t) * env * 0.45, -0.9, 0.9) * 32767.0)
		bytes.append(sample & 0xff)
		bytes.append((sample >> 8) & 0xff)
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.stereo = false
	stream.data = bytes
	return stream

func _build_menu_background() -> void:
	_build_world()
	# Scenic ice crystals, aurora pillars and reflective-looking ice.
	for i in range(18):
		var h := randf_range(2.0, 6.0)
		var crystal := _make_visual_box("Aurora Crystal", Vector3(randf_range(-13.0, 13.0), h * 0.5, randf_range(-22.0, 12.0)), Vector3(0.35, h, 0.35), [Color(0.12, 0.75, 1.0), Color(0.32, 0.45, 1.0), Color(0.62, 0.85, 1.0)][i % 3])
		crystal.rotation_degrees.z = randf_range(-12.0, 12.0)
		world_root.add_child(crystal)
	# Distant fantasy ice castle silhouette for the main-menu vista.
	for i in range(5):
		var tower_h: float = [4.0, 6.2, 8.0, 6.2, 4.0][i]
		var tower_x := -8.0 + float(i) * 4.0
		var tower := _make_visual_box("Frost Castle Tower", Vector3(tower_x, tower_h * 0.5, -23.0), Vector3(1.5, tower_h, 1.6), Color(0.28, 0.62, 0.82))
		world_root.add_child(tower)
		var roof_mesh := CylinderMesh.new()
		roof_mesh.top_radius = 0.0
		roof_mesh.bottom_radius = 1.0
		roof_mesh.height = 2.2
		var roof := _visual_mesh("Castle Ice Spire", roof_mesh, Color(0.04, 0.38, 0.68))
		roof.position = Vector3(tower_x, tower_h + 0.6, -23.0)
		world_root.add_child(roof)
	var castle_wall := _make_visual_box("Frost Castle Wall", Vector3(0, 2.0, -23.0), Vector3(12.0, 4.0, 1.4), Color(0.20, 0.48, 0.68))
	world_root.add_child(castle_wall)
	# Architectural detailing: illuminated lancet windows, buttresses and layered ice roofs.
	for i in range(9):
		var wx := -5.0 + float(i) * 1.25
		var window := _make_visual_box("Castle Glowing Window", Vector3(wx, 2.25 + (0.45 if i % 2 == 0 else 0.0), -22.15), Vector3(0.22, 0.82, 0.08), Color(0.18, 0.88, 1.0))
		world_root.add_child(window)
		var window_glow := OmniLight3D.new()
		window_glow.position = Vector3(wx, 2.4, -21.7)
		window_glow.light_color = Color(0.08, 0.58, 1.0)
		window_glow.light_energy = 0.45
		window_glow.omni_range = 2.2
		world_root.add_child(window_glow)
	for i in range(6):
		var buttress := _make_visual_box("Castle Ice Buttress", Vector3(-5.0 + float(i) * 2.0, 1.8, -21.95), Vector3(0.32, 3.5, 0.48), Color(0.32, 0.68, 0.88))
		world_root.add_child(buttress)
	for i in range(5):
		var roof_base := _make_visual_box("Castle Tower Ice Cornice", Vector3(-8.0 + float(i) * 4.0, [4.0, 6.2, 8.0, 6.2, 4.0][i], -22.9), Vector3(1.9, 0.18, 2.0), Color(0.58, 0.85, 1.0))
		world_root.add_child(roof_base)
	for side in [-1.0, 1.0]:
		for i in range(4):
			var mountain_h := 5.0 + float((i * 3) % 5)
			var mountain_mesh := PrismMesh.new()
			mountain_mesh.size = Vector3(6.0, mountain_h, 5.0)
			var mountain := _visual_mesh("Distant Snow Mountain", mountain_mesh, Color(0.30, 0.57, 0.76))
			mountain.position = Vector3(side * (9.0 + float(i) * 3.0), mountain_h * 0.20, -16.0 - float(i % 2) * 4.0)
			world_root.add_child(mountain)
	# Detailed custom penguin showcase model; the playable character keeps its collision/controller rig.
	var hero_scene: PackedScene = load("res://assets/models/kobra_penguin_hero.glb") as PackedScene
	if hero_scene != null:
		var showcase_hero := hero_scene.instantiate() as Node3D
		showcase_hero.name = "DetailedKobraPenguinShowcase"
		showcase_hero.position = Vector3(3.8, 0.15, 1.0)
		showcase_hero.scale = Vector3(0.85, 0.85, 0.85)
		world_root.add_child(showcase_hero)

	# Imported custom GLB castle asset, layered behind the menu scenery.
	var castle_scene: PackedScene = load("res://assets/models/ice_castle_detailed.glb") as PackedScene
	if castle_scene != null:
		var imported_castle := castle_scene.instantiate() as Node3D
		imported_castle.name = "ImportedDetailedIceCastle"
		imported_castle.position = Vector3(0.0, -0.3, -29.0)
		imported_castle.scale = Vector3(1.2, 1.2, 1.2)
		world_root.add_child(imported_castle)

	# Snow-covered pine trees frame the menu and sway in the wind.
	menu_trees.clear()
	for side in [-1.0, 1.0]:
		for i in range(7):
			var tree_root := Node3D.new()
			tree_root.name = "WindSwayPine"
			tree_root.position = Vector3(side * (7.0 + float(i % 3) * 2.0), 0.0, -13.0 + float(i) * 3.5)
			world_root.add_child(tree_root)
			var trunk_mesh := CylinderMesh.new()
			trunk_mesh.top_radius = 0.12
			trunk_mesh.bottom_radius = 0.22
			trunk_mesh.height = 1.8
			var trunk := _visual_mesh("Pine Trunk", trunk_mesh, Color(0.18, 0.10, 0.08))
			trunk.position.y = 0.9
			tree_root.add_child(trunk)
			for tier in range(3):
				var foliage_mesh := PrismMesh.new()
				foliage_mesh.size = Vector3(1.7 - float(tier) * 0.32, 2.2, 1.7 - float(tier) * 0.32)
				var foliage := _visual_mesh("Snow Pine Foliage", foliage_mesh, Color(0.025, 0.19 + float(tier) * 0.035, 0.24))
				foliage.position.y = 1.7 + float(tier) * 0.85
				tree_root.add_child(foliage)
				var snow_cap := _make_visual_box("Snow Cap", Vector3(0.0, 2.65 + float(tier) * 0.85, 0.0), Vector3(1.05 - float(tier) * 0.2, 0.12, 1.05 - float(tier) * 0.2), Color(0.72, 0.92, 1.0))
				tree_root.add_child(snow_cap)
			menu_trees.append(tree_root)

	# GPU particles create continuous snowfall and wind-driven drift.
	snow_particles = GPUParticles3D.new()
	snow_particles.name = "LivingSnowfall"
	snow_particles.amount = 850
	snow_particles.lifetime = 9.0
	snow_particles.explosiveness = 0.0
	snow_particles.randomness = 0.8
	snow_particles.position = Vector3(0.0, 7.0, -2.0)
	var snow_process := ParticleProcessMaterial.new()
	snow_process.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	snow_process.emission_box_extents = Vector3(17.0, 7.0, 20.0)
	snow_process.direction = Vector3(0.35, -1.0, 0.08)
	snow_process.spread = 18.0
	snow_process.initial_velocity_min = 0.8
	snow_process.initial_velocity_max = 2.2
	snow_process.gravity = Vector3(1.1, -0.25, 0.0)
	snow_process.scale_min = 0.025
	snow_process.scale_max = 0.075
	snow_process.angular_velocity_min = -0.8
	snow_process.angular_velocity_max = 0.8
	snow_particles.process_material = snow_process
	var snow_mesh := SphereMesh.new()
	snow_mesh.radius = 0.045
	snow_mesh.height = 0.09
	var snow_mat := StandardMaterial3D.new()
	snow_mat.albedo_color = Color(0.78, 0.93, 1.0)
	snow_mat.emission_enabled = true
	snow_mat.emission = Color(0.2, 0.55, 1.0)
	snow_mat.emission_energy_multiplier = 0.35
	snow_mesh.material = snow_mat
	snow_particles.draw_pass_1 = snow_mesh
	world_root.add_child(snow_particles)
	snow_particles.emitting = true

	if not is_instance_valid(camera):
		camera = Camera3D.new()
		camera.name = "MenuCamera"
		camera.current = true
		camera.fov = 64.0
		add_child(camera)
	camera.position = Vector3(0, 6.0, 19.0)
	camera.fov = 58.0
	camera.look_at(Vector3(0, 1.8, -3.0), Vector3.UP)
	# Showcase penguin centered for portrait composition.
	_build_player()
	player.position = Vector3(1.1, 1.2, 1.0)

func _show_intro() -> void:
	# Real-time procedural 3D intro, not flat image frames.
	var intro := Node3D.new()
	intro.name = "Kobratix3DIntro"
	add_child(intro)
	var previous_camera := get_viewport().get_camera_3d()
	var intro_camera := Camera3D.new()
	intro_camera.name = "IntroCamera3D"
	intro_camera.fov = 58.0
	intro_camera.position = Vector3(0.0, 0.0, 12.0)
	intro.add_child(intro_camera)
	intro_camera.look_at(Vector3.ZERO, Vector3.UP)
	intro_camera.make_current()

	var backdrop := MeshInstance3D.new()
	var backdrop_mesh := PlaneMesh.new()
	backdrop_mesh.size = Vector2(80.0, 45.0)
	backdrop.mesh = backdrop_mesh
	var black_mat := StandardMaterial3D.new()
	black_mat.albedo_color = Color(0.001, 0.003, 0.009)
	black_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	backdrop.material_override = black_mat
	backdrop.position.z = -5.0
	intro.add_child(backdrop)

	var light := OmniLight3D.new()
	light.position = Vector3(0.0, 1.0, 4.0)
	light.light_color = Color(0.05, 0.55, 1.0)
	light.light_energy = 3.0
	light.omni_range = 24.0
	intro.add_child(light)

	var rings: Array[MeshInstance3D] = []
	for i in range(3):
		var mesh := TorusMesh.new()
		mesh.inner_radius = 1.6 + float(i) * 0.3
		mesh.outer_radius = mesh.inner_radius + 0.045
		mesh.rings = 48
		mesh.ring_segments = 12
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.08, 0.65 + float(i) * 0.08, 1.0)
		mat.emission_enabled = true
		mat.emission = Color(0.0, 0.38, 1.0)
		mat.emission_energy_multiplier = 2.2
		mat.metallic = 0.65
		mat.roughness = 0.2
		var ring := MeshInstance3D.new()
		ring.mesh = mesh
		ring.material_override = mat
		ring.rotation = Vector3(0.3 + float(i) * 0.4, 0.0, 0.2 + float(i) * 0.5)
		ring.scale = Vector3.ZERO
		intro.add_child(ring)
		rings.append(ring)

	var logo_mat := StandardMaterial3D.new()
	logo_mat.albedo_color = Color(0.55, 0.9, 1.0)
	logo_mat.metallic = 0.8
	logo_mat.roughness = 0.16
	logo_mat.emission_enabled = true
	logo_mat.emission = Color(0.0, 0.35, 1.0)
	logo_mat.emission_energy_multiplier = 1.5
	var logo := Label3D.new()
	logo.name = "KOBRATIX3DLogo"
	logo.text = "KOBRATIX"
	logo.font_size = 104
	logo.pixel_size = 0.0065
	logo.position = Vector3(0.0, 0.1, 0.0)
	logo.scale = Vector3(0.01, 0.01, 0.01)
	logo.modulate.a = 0.0
	logo.material_override = logo_mat
	logo.outline_size = 12
	logo.outline_modulate = Color(0.0, 0.4, 1.0, 1.0)
	intro.add_child(logo)

	# A small three-point metallic crown above the creator wordmark.
	var crown_root := Node3D.new()
	crown_root.name = "KobratixIceCrown"
	crown_root.position = Vector3(0.0, 1.08, 0.05)
	crown_root.scale = Vector3.ZERO
	intro.add_child(crown_root)
	var crown_base_mesh := BoxMesh.new()
	crown_base_mesh.size = Vector3(1.05, 0.13, 0.12)
	var crown_mat := StandardMaterial3D.new()
	crown_mat.albedo_color = Color(0.52, 0.86, 1.0)
	crown_mat.metallic = 0.85
	crown_mat.roughness = 0.16
	crown_mat.emission_enabled = true
	crown_mat.emission = Color(0.0, 0.42, 1.0)
	crown_mat.emission_energy_multiplier = 1.8
	var crown_base := MeshInstance3D.new()
	crown_base.mesh = crown_base_mesh
	crown_base.material_override = crown_mat
	crown_root.add_child(crown_base)
	for i in range(5):
		var spike_mesh := PrismMesh.new()
		spike_mesh.size = Vector3(0.20, 0.42 if i % 2 == 0 else 0.27, 0.13)
		var spike := MeshInstance3D.new()
		spike.mesh = spike_mesh
		spike.material_override = crown_mat
		spike.position = Vector3(-0.42 + float(i) * 0.21, 0.18 + (0.08 if i % 2 == 0 else 0.0), 0.0)
		crown_root.add_child(spike)
	var crown_gem_mesh := SphereMesh.new()
	crown_gem_mesh.radius = 0.07
	crown_gem_mesh.height = 0.12
	var crown_gem_mat := StandardMaterial3D.new()
	crown_gem_mat.albedo_color = Color(0.0, 0.92, 1.0)
	crown_gem_mat.emission_enabled = true
	crown_gem_mat.emission = Color(0.0, 0.7, 1.0)
	crown_gem_mat.emission_energy_multiplier = 2.5
	var crown_gem := MeshInstance3D.new()
	crown_gem.mesh = crown_gem_mesh
	crown_gem.material_override = crown_gem_mat
	crown_gem.position = Vector3(0.0, 0.31, -0.08)
	crown_root.add_child(crown_gem)

	var creator := Label3D.new()
	creator.text = "CREATED BY KOBRATIX"
	creator.font_size = 26
	creator.pixel_size = 0.006
	creator.position = Vector3(0.0, -0.9, 0.0)
	creator.modulate.a = 0.0
	intro.add_child(creator)

	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var shards: Array[MeshInstance3D] = []
	for i in range(52):
		var shard_mesh := BoxMesh.new()
		var size := rng.randf_range(0.04, 0.13)
		shard_mesh.size = Vector3(size, size * rng.randf_range(0.8, 2.0), size)
		var shard_mat := StandardMaterial3D.new()
		shard_mat.albedo_color = Color(0.25, 0.78 + rng.randf() * 0.2, 1.0)
		shard_mat.emission_enabled = true
		shard_mat.emission = Color(0.0, 0.3, 1.0)
		shard_mat.emission_energy_multiplier = 1.2
		var shard := MeshInstance3D.new()
		shard.mesh = shard_mesh
		shard.material_override = shard_mat
		shard.position = Vector3(rng.randf_range(-5.5, 5.5), rng.randf_range(-3.0, 3.0), rng.randf_range(-1.0, 2.0))
		shard.scale = Vector3.ZERO
		intro.add_child(shard)
		shards.append(shard)

	var title_mat := StandardMaterial3D.new()
	title_mat.albedo_color = Color(0.65, 0.9, 1.0)
	title_mat.metallic = 0.7
	title_mat.roughness = 0.2
	title_mat.emission_enabled = true
	title_mat.emission = Color(0.0, 0.38, 1.0)
	title_mat.emission_energy_multiplier = 1.5
	var game_title := Label3D.new()
	game_title.name = "PenguinLegends3DTitle"
	game_title.text = "PENGUIN\\nLEGENDS 3D"
	game_title.font_size = 78
	game_title.pixel_size = 0.006
	game_title.scale = Vector3(0.01, 0.01, 0.01)
	game_title.modulate.a = 0.0
	game_title.material_override = title_mat
	intro.add_child(game_title)
	var loading := Label3D.new()
	loading.text = "LOADING  •  CREATED BY KOBRATIX"
	loading.font_size = 20
	loading.pixel_size = 0.006
	loading.position = Vector3(0.0, -1.45, 0.0)
	loading.modulate.a = 0.0
	intro.add_child(loading)

	if is_instance_valid(intro_player):
		intro_player.play()
	var tw := create_tween()
	tw.set_parallel(true)
	for ring in rings:
		tw.tween_property(ring, "scale", Vector3.ONE, 1.0).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(intro_camera, "position:z", 10.4, 1.4).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tw.tween_property(logo, "scale", Vector3.ONE, 1.0).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(crown_root, "scale", Vector3.ONE, 0.85).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(logo, "modulate:a", 1.0, 0.7)
	tw.tween_property(creator, "modulate:a", 1.0, 0.9).set_delay(0.55)
	for shard in shards:
		tw.tween_property(shard, "scale", Vector3.ONE, rng.randf_range(0.3, 0.8)).set_delay(rng.randf_range(0.0, 0.7))
	tw.chain().tween_interval(1.7)
	tw.tween_property(logo, "scale", Vector3(1.08, 1.08, 1.08), 0.25)
	tw.tween_property(logo, "scale", Vector3.ONE, 0.2)
	tw.tween_interval(0.45)
	tw.tween_property(logo, "modulate:a", 0.0, 0.5)
	tw.parallel().tween_property(crown_root, "scale", Vector3(0.01, 0.01, 0.01), 0.5)
	tw.parallel().tween_property(creator, "modulate:a", 0.0, 0.4)
	tw.parallel().tween_property(game_title, "modulate:a", 1.0, 0.65)
	tw.parallel().tween_property(game_title, "scale", Vector3.ONE, 0.8).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(loading, "modulate:a", 1.0, 0.6)
	tw.tween_interval(1.8)
	tw.tween_property(game_title, "scale", Vector3(1.07, 1.07, 1.07), 0.25)
	tw.tween_property(game_title, "scale", Vector3.ONE, 0.2)
	tw.tween_interval(0.3)
	tw.tween_property(game_title, "modulate:a", 0.0, 0.45)
	tw.parallel().tween_property(loading, "modulate:a", 0.0, 0.4)
	for ring in rings:
		tw.parallel().tween_property(ring, "scale", Vector3(1.7, 1.7, 1.7), 0.6)
		tw.parallel().tween_property(ring, "transparency", 1.0, 0.6)
	for shard in shards:
		tw.parallel().tween_property(shard, "scale", Vector3.ZERO, 0.55)
	tw.tween_callback(func():
		intro.queue_free()
		if is_instance_valid(previous_camera):
			previous_camera.current = true
	)

func _build_main_menu() -> void:
	menu_open = true
	menu_layer = CanvasLayer.new()
	menu_layer.name = "MainMenu"
	menu_layer.layer = 10
	add_child(menu_layer)
	menu_root = Control.new()
	menu_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_layer.add_child(menu_root)

	# Cinematic overlay: keep the 3D ice world and showcase penguin visible.
	var shade := ColorRect.new()
	shade.color = Color(0.002, 0.012, 0.035, 0.28)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_root.add_child(shade)
	var left_fade := ColorRect.new()
	left_fade.color = Color(0.005, 0.025, 0.065, 0.80)
	left_fade.anchor_left = 0.0
	left_fade.anchor_right = 1.0
	left_fade.anchor_top = 0.0
	left_fade.anchor_bottom = 1.0
	left_fade.offset_right = 0.0
	left_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_root.add_child(left_fade)

	var top_tag := Label.new()
	top_tag.text = "KOBRATIX  /  ORIGINAL GAME"
	top_tag.anchor_left = 0.06
	top_tag.anchor_right = 0.94
	top_tag.anchor_top = 0.025
	top_tag.anchor_bottom = 0.055
	top_tag.add_theme_font_size_override("font_size", 12)
	top_tag.add_theme_color_override("font_color", Color(0.25, 0.86, 1.0))
	menu_root.add_child(top_tag)

	var title := Label.new()
	title.text = "PENGUIN\nLEGENDS 3D"
	title.anchor_left = 0.05
	title.anchor_right = 0.95
	title.anchor_top = 0.07
	title.anchor_bottom = 0.19
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 38)
	title.add_theme_color_override("font_color", Color(0.84, 0.97, 1.0))
	title.add_theme_color_override("font_shadow_color", Color(0.0, 0.62, 1.0, 0.95))
	title.add_theme_constant_override("shadow_offset_x", 0)
	title.add_theme_constant_override("shadow_offset_y", 0)
	title.add_theme_constant_override("shadow_outline_size", 8)
	menu_root.add_child(title)

	var subtitle := Label.new()
	subtitle.text = "RISE OF THE FROST LEGENDS"
	subtitle.anchor_left = 0.05
	subtitle.anchor_right = 0.95
	subtitle.anchor_top = 0.19
	subtitle.anchor_bottom = 0.225
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 12)
	subtitle.add_theme_color_override("font_color", Color(1.0, 0.72, 0.20))
	menu_root.add_child(subtitle)

	var card := PanelContainer.new()
	card.anchor_left = 0.07
	card.anchor_right = 0.93
	card.anchor_top = 0.60
	card.anchor_bottom = 0.91
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color(0.008, 0.045, 0.09, 0.90)
	panel_style.border_color = Color(0.0, 0.78, 1.0, 0.92)
	panel_style.set_border_width_all(2)
	panel_style.set_corner_radius_all(20)
	panel_style.content_margin_left = 14
	panel_style.content_margin_right = 14
	panel_style.content_margin_top = 14
	panel_style.content_margin_bottom = 14
	card.add_theme_stylebox_override("panel", panel_style)
	menu_root.add_child(card)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 10)
	card.add_child(stack)

	var choose := Label.new()
	choose.text = "CHOOSE YOUR PENGUIN"
	choose.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	choose.add_theme_font_size_override("font_size", 14)
	choose.add_theme_color_override("font_color", Color(0.68, 0.91, 1.0))
	stack.add_child(choose)
	var penguin_picker := OptionButton.new()
	for skin_name in penguin_names:
		penguin_picker.add_item(skin_name)
	penguin_picker.selected = selected_penguin
	penguin_picker.item_selected.connect(_select_penguin)
	penguin_picker.custom_minimum_size = Vector2(0, 42)
	stack.add_child(penguin_picker)

	var start := _menu_button("▶   PLAY", Color(0.0, 0.42, 0.68))
	start.custom_minimum_size.y = 54
	start.pressed.connect(_start_game)
	stack.add_child(start)
	var settings := _menu_button("⚙   SETTINGS", Color(0.025, 0.16, 0.30))
	settings.custom_minimum_size.y = 48
	settings.pressed.connect(_show_settings)
	stack.add_child(settings)
	var continue_button := _menu_button("↻   CONTINUE ADVENTURE", Color(0.025, 0.16, 0.30))
	continue_button.custom_minimum_size.y = 48
	continue_button.pressed.connect(_continue_game)
	stack.add_child(continue_button)

	var note := Label.new()
	note.text = "200 LEVELS  •  20 BOSSES  •  ICE POWERS"
	note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	note.add_theme_font_size_override("font_size", 10)
	note.add_theme_color_override("font_color", Color(0.46, 0.78, 0.95))
	stack.add_child(note)

	var footer := Label.new()
	footer.text = "CREATED BY KOBRATIX"
	footer.anchor_left = 0.06
	footer.anchor_right = 0.94
	footer.anchor_top = 0.94
	footer.anchor_bottom = 0.98
	footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	footer.add_theme_font_size_override("font_size", 15)
	footer.add_theme_color_override("font_color", Color(0.0, 0.82, 1.0))
	menu_root.add_child(footer)
	var footer_tween := create_tween().set_loops()
	footer_tween.tween_property(footer, "modulate", Color(0.45, 0.88, 1.0), 0.8)
	footer_tween.tween_property(footer, "modulate", Color.WHITE, 0.8)
	var title_tween := create_tween().set_loops()
	title_tween.tween_property(title, "scale", Vector2(1.025, 1.025), 1.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	title_tween.tween_property(title, "scale", Vector2.ONE, 1.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

func _menu_button(caption: String, color: Color) -> Button:
	var button := Button.new()
	button.text = caption
	button.custom_minimum_size = Vector2(0, 52)
	button.add_theme_font_size_override("font_size", 17)
	button.add_theme_color_override("font_color", Color(0.91, 0.98, 1.0))
	button.add_theme_color_override("font_hover_color", Color.WHITE)
	button.add_theme_color_override("font_pressed_color", Color.WHITE)
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = Color(0.0, 0.76, 1.0, 0.95)
	style.set_border_width_all(2)
	style.set_corner_radius_all(13)
	style.content_margin_left = 12
	style.content_margin_right = 12
	button.add_theme_stylebox_override("normal", style)
	var hover := style.duplicate()
	hover.bg_color = color.lightened(0.24)
	hover.border_color = Color(0.48, 0.95, 1.0)
	button.add_theme_stylebox_override("hover", hover)
	var pressed := style.duplicate()
	pressed.bg_color = Color(0.0, 0.34, 0.50)
	button.add_theme_stylebox_override("pressed", pressed)
	return button

func _select_penguin(index: int) -> void:
	selected_penguin = clampi(index, 0, penguin_colors.size() - 1)
	if is_instance_valid(player):
		var body := player.get_node_or_null("Penguin Body/Visual")
		# Rebuild showcase hero so all color pieces match the selected skin.
		player.queue_free()
		_build_player()
		player.position = Vector3(3.8, 1.2, 1.0)

func _start_game() -> void:
	_begin_game(1)

func _continue_game() -> void:
	_begin_game(level)

func _begin_game(start_level: int) -> void:
	if is_instance_valid(menu_layer): menu_layer.queue_free()
	menu_open = false
	level = clampi(start_level, 1, MAX_LEVEL)
	_clear_world()
	_build_world()
	if is_instance_valid(player): player.queue_free()
	_build_player()
	_build_hud()
	_update_hud()

func _show_settings() -> void:
	var dialog := AcceptDialog.new()
	dialog.title = "SETTINGS"
	dialog.dialog_text = "Music: %s\\nSoundtrack and intro audio are generated locally.\\nControls: tilt phone to move; use on-screen JUMP, ICE and BLAST buttons." % ("ON" if music_enabled else "OFF")
	menu_root.add_child(dialog)
	dialog.add_button("TOGGLE MUSIC", true, "toggle_music")
	dialog.confirmed.connect(func(): pass)
	dialog.custom_action.connect(func(action: String):
		if action == "toggle_music":
			music_enabled = not music_enabled
			if music_enabled: music_player.play()
			else: music_player.stop()
	)
	dialog.popup_centered(Vector2i(560, 260))

func _process(delta: float) -> void:
	elapsed += delta
	if menu_open:
		if is_instance_valid(player):
			player.rotate_y(delta * 0.12)
			player.position.y = 1.2 + sin(elapsed * 1.5) * 0.07
		for i in range(menu_trees.size()):
			var tree: Node3D = menu_trees[i]
			if is_instance_valid(tree):
				tree.rotation.z = sin(elapsed * 0.72 + float(i) * 0.8) * 0.055 + sin(elapsed * 1.4 + float(i)) * 0.018
				tree.rotation.x = cos(elapsed * 0.55 + float(i) * 0.6) * 0.025
		if is_instance_valid(snow_particles):
			var snow_process := snow_particles.process_material as ParticleProcessMaterial
			if snow_process:
				snow_process.gravity.x = 1.1 + sin(elapsed * 0.65) * 1.2
				snow_process.direction.x = 0.35 + sin(elapsed * 0.7) * 0.3
		return
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	special_cooldown = maxf(0.0, special_cooldown - delta)
	invulnerable = maxf(0.0, invulnerable - delta)
	if mobile:
		# Accelerometer X measures side-to-side tilt in portrait mode.
		# Smooth the signal and leave touch buttons available as a fallback.
		var accel := Input.get_accelerometer()
		var sensor_axis := clampf(accel.x / 3.5, -1.0, 1.0)
		if absf(accel.x) > 0.35:
			tilt_axis = lerpf(tilt_axis, sensor_axis, clampf(delta * 8.0, 0.0, 1.0))
		else:
			tilt_axis = lerpf(tilt_axis, 0.0, clampf(delta * 3.0, 0.0, 1.0))
	for coin in coins_in_world:
		if is_instance_valid(coin):
			coin.rotate_y(delta * 2.0)
			coin.position.y = 0.8 + sin(elapsed * 2.4 + coin.position.z) * 0.12
	for enemy in enemies:
		if is_instance_valid(enemy):
			enemy.position.x = enemy.get_meta("home_x", 0.0) + sin(elapsed * 1.4 + enemy.position.z) * 1.4
	if boss_active and is_instance_valid(boss):
		boss.position.x = sin(elapsed * 0.9) * 2.8
		if player and player.global_position.distance_to(boss.global_position) < 3.2 and invulnerable <= 0.0:
			_take_hit(12)
	_update_hud()

func _physics_process(delta: float) -> void:
	if menu_open or not is_instance_valid(player) or game_over:
		return
	var axis := Input.get_axis("move_left", "move_right")
	if mobile:
		if absf(touch_move_axis) > 0.1:
			axis = touch_move_axis
		elif absf(tilt_axis) > 0.12:
			axis = tilt_axis
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		axis = -1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		axis = 1.0
	player.velocity.x = move_toward(player.velocity.x, axis * 7.0, 22.0 * delta)
	player.velocity.z = move_toward(player.velocity.z, -3.0, 8.0 * delta)
	if not player.is_on_floor():
		player.velocity.y -= GRAVITY * delta
	elif jump_requested or Input.is_action_just_pressed("jump") or Input.is_key_pressed(KEY_SPACE):
		player.velocity.y = 8.0
	jump_requested = false
	player.move_and_slide()
	player.position.x = clampf(player.position.x, -10.0, 10.0)
	if player.position.y < -5.0:
		_take_hit(25)
		player.position = Vector3(0, 1.2, 8)
		player.velocity = Vector3.ZERO
	if attack_requested:
		_attack(false)
		attack_requested = false
	if special_requested:
		_attack(true)
		special_requested = false
	if player.position.z < -22.0:
		_complete_level()

func _build_world() -> void:
	world_root = Node3D.new()
	world_root.name = "LevelWorld"
	add_child(world_root)
	var env_node := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color(0.025, 0.09, 0.23)
	sky_material.sky_horizon_color = Color(0.28, 0.62, 0.82)
	sky_material.ground_bottom_color = Color(0.04, 0.1, 0.18)
	sky_material.ground_horizon_color = Color(0.55, 0.78, 0.9)
	sky.sky_material = sky_material
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.58, 0.72, 0.88)
	environment.ambient_light_energy = 0.85
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.glow_enabled = true
	environment.glow_intensity = 0.7
	env_node.environment = environment
	world_root.add_child(env_node)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -28, 0)
	sun.light_energy = 1.35
	sun.shadow_enabled = true
	world_root.add_child(sun)

	var floor := _make_box("Glacier Path", Vector3(0, -0.5, 0), Vector3(23, 1, 60), _world_color())
	world_root.add_child(floor)
	for side in [-1.0, 1.0]:
		for i in range(7):
			var peak_height := 5.0 + float((i + level) % 5) * 1.4
			var peak := _make_visual_box("Ice Cliff", Vector3.ZERO, Vector3(3.0, peak_height, 4.0), Color(0.12, 0.34, 0.55))
			peak.position = Vector3(side * (13.0 + float(i % 2)), peak_height * 0.35, -20.0 + float(i) * 6.0)
			world_root.add_child(peak)
	for i in range(6):
		var z := 3.0 - float(i) * 4.0
		var side_x := -5.0 if i % 2 == 0 else 5.0
		var platform := _make_box("Floating Ice Platform", Vector3(side_x, 0.65, z), Vector3(3.0, 0.45, 2.8), Color(0.65, 0.9, 1.0))
		world_root.add_child(platform)
	for i in range(15):
		var pos := Vector3(randf_range(-8.0, 8.0), 0.9, randf_range(-20.0, 18.0))
		_make_coin(pos)
	for i in range(4 + int(level / 8)):
		_make_enemy(Vector3(randf_range(-7.0, 7.0), 0.5, randf_range(-18.0, 10.0)))
	if level % 10 == 0:
		_spawn_boss()
	else:
		var gate := _make_visual_box("Glacier Gate", Vector3(0, 1.3, -23.0), Vector3(5.0, 2.8, 0.6), Color(0.1, 0.55, 0.78))
		world_root.add_child(gate)
	# Reuse a single camera; attach it to the root for stable Android rendering.
	if not is_instance_valid(camera):
		camera = Camera3D.new()
		camera.name = "AdventureCamera"
		camera.current = true
		camera.fov = 72.0
		add_child(camera)
	camera.position = Vector3(0, 8.5, 15.5)
	camera.rotation_degrees = Vector3(-25, 0, 0)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "PenguinHero"
	player.position = Vector3(0, 1.2, 8)
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.46
	capsule.height = 1.45
	collision.shape = capsule
	collision.position.y = 0.75
	player.add_child(collision)
	var body := _visual_mesh("Penguin Body", CapsuleMesh.new(), penguin_colors[selected_penguin])
	body.position.y = 0.75
	player.add_child(body)
	var belly_mesh := SphereMesh.new()
	belly_mesh.radius = 0.34
	belly_mesh.height = 0.76
	var belly := _visual_mesh("Snow White Belly", belly_mesh, Color(0.93, 0.97, 1.0))
	belly.position = Vector3(0, 0.72, -0.31)
	player.add_child(belly)
	var head_mesh := SphereMesh.new()
	head_mesh.radius = 0.38
	head_mesh.height = 0.7
	var head := _visual_mesh("Penguin Head", head_mesh, penguin_colors[selected_penguin])
	head.position = Vector3(0, 1.42, -0.03)
	player.add_child(head)
	for side in [-1.0, 1.0]:
		var eye_mesh := SphereMesh.new()
		eye_mesh.radius = 0.075
		var eye := _visual_mesh("Eye", eye_mesh, Color.WHITE)
		eye.position = Vector3(side * 0.15, 1.48, -0.36)
		player.add_child(eye)
		var pupil_mesh := SphereMesh.new()
		pupil_mesh.radius = 0.035
		var pupil := _visual_mesh("Pupil", pupil_mesh, Color(0.015, 0.02, 0.03))
		pupil.position = Vector3(side * 0.15, 1.48, -0.42)
		player.add_child(pupil)
	var beak_mesh := PrismMesh.new()
	beak_mesh.size = Vector3(0.24, 0.14, 0.22)
	var beak := _visual_mesh("Orange Beak", beak_mesh, Color(1.0, 0.43, 0.035))
	beak.position = Vector3(0, 1.32, -0.45)
	player.add_child(beak)
	# Layered feather tufts around the cheeks and crown make the silhouette less primitive.
	for side in [-1.0, 1.0]:
		for i in range(3):
			var feather_mesh := SphereMesh.new()
			feather_mesh.radius = 0.105 - float(i) * 0.012
			feather_mesh.height = 0.25
			var feather := _visual_mesh("Blue Black Feather Tuft", feather_mesh, penguin_colors[selected_penguin].lightened(0.12))
			feather.position = Vector3(side * (0.29 + float(i) * 0.035), 1.34 + float(i) * 0.10, -0.19 + float(i) * 0.045)
			feather.rotation.z = side * -0.35
			feather.scale = Vector3(0.8, 1.0, 0.65)
			player.add_child(feather)
		var brow_mesh := BoxMesh.new()
		brow_mesh.size = Vector3(0.18, 0.055, 0.07)
		var brow := _visual_mesh("Angry Hero Eyebrow", brow_mesh, Color(0.012, 0.018, 0.03))
		brow.position = Vector3(side * 0.15, 1.59, -0.405)
		brow.rotation.z = side * -0.22
		player.add_child(brow)

	# Thick blue scarf loop with a separate trailing flap and gold clasp.
	var scarf_mesh := TorusMesh.new()
	scarf_mesh.inner_radius = 0.31
	scarf_mesh.outer_radius = 0.43
	scarf_mesh.rings = 36
	scarf_mesh.ring_segments = 12
	var scarf := _visual_mesh("Arctic Blue Scarf", scarf_mesh, Color(0.015, 0.32, 0.82))
	scarf.position = Vector3(0.0, 1.12, -0.015)
	scarf.rotation.x = 0.12
	player.add_child(scarf)
	var scarf_flap_mesh := BoxMesh.new()
	scarf_flap_mesh.size = Vector3(0.28, 0.62, 0.09)
	var scarf_flap := _visual_mesh("Scarf Flowing Tail", scarf_flap_mesh, Color(0.025, 0.42, 0.96))
	scarf_flap.position = Vector3(-0.24, 0.93, 0.26)
	scarf_flap.rotation.z = -0.22
	player.add_child(scarf_flap)
	var scarf_trim := _make_visual_box("Scarf Gold Stitch", Vector3(-0.24, 0.99, 0.205), Vector3(0.25, 0.035, 0.025), Color(1.0, 0.68, 0.16))
	player.add_child(scarf_trim)
	var clasp_mesh := BoxMesh.new()
	clasp_mesh.size = Vector3(0.13, 0.16, 0.06)
	var clasp := _visual_mesh("Scarf Clasp", clasp_mesh, Color(1.0, 0.63, 0.12))
	clasp.position = Vector3(0.18, 1.09, -0.36)
	player.add_child(clasp)

	# Small explorer pack and diagonal leather harness.
	var pack_mesh := BoxMesh.new()
	pack_mesh.size = Vector3(0.48, 0.62, 0.22)
	var pack := _visual_mesh("Explorer Backpack", pack_mesh, Color(0.20, 0.075, 0.035))
	pack.position = Vector3(0.0, 0.83, 0.34)
	player.add_child(pack)
	var pack_top := _make_visual_box("Backpack Top Flap", Vector3(0.0, 1.17, 0.22), Vector3(0.48, 0.12, 0.18), Color(0.32, 0.12, 0.045))
	player.add_child(pack_top)
	for side in [-1.0, 1.0]:
		var strap_mesh := BoxMesh.new()
		strap_mesh.size = Vector3(0.09, 0.86, 0.055)
		var strap := _visual_mesh("Leather Harness Strap", strap_mesh, Color(0.32, 0.12, 0.045))
		strap.position = Vector3(side * 0.20, 0.87, -0.335)
		strap.rotation.z = side * -0.18
		player.add_child(strap)
	for i in range(3):
		var stitch := _make_visual_box("Harness Stitch", Vector3(-0.18 + float(i) * 0.18, 0.76, -0.371), Vector3(0.045, 0.025, 0.018), Color(0.95, 0.65, 0.24))
		player.add_child(stitch)
	for side in [-1.0, 1.0]:
		var flipper_mesh := BoxMesh.new()
		flipper_mesh.size = Vector3(0.2, 0.68, 0.28)
		var flipper := _visual_mesh("Flipper", flipper_mesh, penguin_colors[selected_penguin])
		flipper.position = Vector3(side * 0.53, 0.78, 0.0)
		flipper.rotation.z = side * -0.18
		player.add_child(flipper)
		var foot_mesh := BoxMesh.new()
		foot_mesh.size = Vector3(0.34, 0.12, 0.38)
		var foot := _visual_mesh("Orange Foot", foot_mesh, Color(1.0, 0.35, 0.025))
		foot.position = Vector3(side * 0.22, 0.12, -0.17)
		player.add_child(foot)
	add_child(player)

func _build_hud() -> void:
	hud = CanvasLayer.new()
	hud.name = "GameHUD"
	add_child(hud)
	var panel := PanelContainer.new()
	panel.position = Vector2(14, 14)
	panel.custom_minimum_size = Vector2(330, 104)
	hud.add_child(panel)
	var stack := VBoxContainer.new()
	panel.add_child(stack)
	level_label = Label.new()
	level_label.add_theme_font_size_override("font_size", 21)
	stack.add_child(level_label)
	stats_label = Label.new()
	stats_label.add_theme_font_size_override("font_size", 17)
	stack.add_child(stats_label)
	boss_label = Label.new()
	boss_label.add_theme_color_override("font_color", Color(0.2, 0.85, 1.0))
	stack.add_child(boss_label)
	message_label = Label.new()
	message_label.anchor_left = 0.2
	message_label.anchor_right = 0.8
	message_label.anchor_top = 0.0
	message_label.anchor_bottom = 0.0
	message_label.offset_top = 125
	message_label.offset_bottom = 170
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.add_theme_font_size_override("font_size", 23)
	message_label.add_theme_color_override("font_color", Color(1.0, 0.86, 0.35))
	hud.add_child(message_label)
	_add_movement_button("◀", Vector2(22, -108), Vector2(78, 78), true)
	_add_movement_button("▶", Vector2(112, -108), Vector2(78, 78), false)
	_add_button("JUMP", Vector2(-112, -108), Vector2(96, 82), func(): jump_requested = true)
	_add_button("ICE", Vector2(-220, -92), Vector2(90, 72), func(): attack_requested = true)
	_add_button("BLAST", Vector2(-115, -198), Vector2(100, 72), func(): special_requested = true)
	_add_button("NEXT", Vector2(14, 130), Vector2(100, 52), func(): _complete_level())
	_add_button("PAUSE", Vector2(-105, 14), Vector2(92, 48), func(): _toggle_pause())

func _add_movement_button(caption: String, offset: Vector2, size: Vector2, move_left: bool) -> void:
	var button := Button.new()
	button.text = caption
	button.custom_minimum_size = size
	button.anchor_left = 0.0
	button.anchor_right = 0.0
	button.anchor_top = 1.0
	button.anchor_bottom = 1.0
	button.position = offset
	button.add_theme_font_size_override("font_size", 28)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.025, 0.28, 0.48, 0.82)
	style.border_color = Color(0.25, 0.82, 1.0)
	style.set_border_width_all(2)
	style.set_corner_radius_all(18)
	button.add_theme_stylebox_override("normal", style)
	button.add_theme_stylebox_override("hover", style)
	button.add_theme_stylebox_override("pressed", style)
	button.button_down.connect(func():
		if move_left:
			left_move_pressed = true
		else:
			right_move_pressed = true
		_update_touch_move_axis()
	)
	button.button_up.connect(func():
		if move_left:
			left_move_pressed = false
		else:
			right_move_pressed = false
		_update_touch_move_axis()
	)
	hud.add_child(button)

func _update_touch_move_axis() -> void:
	if left_move_pressed and not right_move_pressed:
		touch_move_axis = -1.0
	elif right_move_pressed and not left_move_pressed:
		touch_move_axis = 1.0
	else:
		touch_move_axis = 0.0

func _add_button(caption: String, offset: Vector2, size: Vector2, action: Callable) -> void:
	var button := Button.new()
	button.text = caption
	button.custom_minimum_size = size
	if offset.x < 0:
		button.anchor_left = 1.0
		button.anchor_right = 1.0
	else:
		button.anchor_left = 0.0
		button.anchor_right = 0.0
	if offset.y < 0:
		button.anchor_top = 1.0
		button.anchor_bottom = 1.0
	else:
		button.anchor_top = 0.0
		button.anchor_bottom = 0.0
	button.position = offset
	button.add_theme_font_size_override("font_size", 18)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.025, 0.28, 0.48, 0.92)
	style.border_color = Color(0.25, 0.82, 1.0)
	style.set_border_width_all(2)
	style.set_corner_radius_all(15)
	button.add_theme_stylebox_override("normal", style)
	button.pressed.connect(action)
	hud.add_child(button)

func _make_box(label: String, pos: Vector3, size: Vector3, color: Color) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = label
	body.position = pos
	var mesh := BoxMesh.new()
	mesh.size = size
	var visual := _visual_mesh(label + " Visual", mesh, color)
	body.add_child(visual)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)
	return body

func _make_visual_box(label: String, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	var visual := _visual_mesh(label, mesh, color)
	visual.position = pos
	return visual

func _visual_mesh(label: String, mesh: Mesh, color: Color) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.name = label
	instance.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.68
	instance.material_override = material
	return instance

func _make_coin(pos: Vector3) -> void:
	var coin := Area3D.new()
	coin.name = "Golden Ice Coin"
	coin.position = pos
	var mesh := SphereMesh.new()
	mesh.radius = 0.23
	mesh.height = 0.46
	var visual := _visual_mesh("Gold", mesh, Color(1.0, 0.68, 0.04))
	coin.add_child(visual)
	var material := visual.material_override as StandardMaterial3D
	material.metallic = 0.55
	material.emission_enabled = true
	material.emission = Color(0.35, 0.15, 0.0)
	var collision := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.72
	collision.shape = shape
	coin.add_child(collision)
	coin.body_entered.connect(_on_coin_body_entered.bind(coin))
	world_root.add_child(coin)
	coins_in_world.append(coin)

func _on_coin_body_entered(body: Node3D, coin: Area3D) -> void:
	if body == player and is_instance_valid(coin):
		coins += 1
		coins_in_world.erase(coin)
		coin.queue_free()
		_update_hud()

func _make_enemy(pos: Vector3) -> void:
	var enemy := Area3D.new()
	enemy.name = "Snow Creature"
	enemy.position = pos
	enemy.set_meta("home_x", pos.x)
	var mesh := SphereMesh.new()
	mesh.radius = 0.5
	mesh.height = 0.95
	var visual := _visual_mesh("Creature Body", mesh, Color(0.55, 0.13, 0.22))
	enemy.add_child(visual)
	var eyes_mesh := BoxMesh.new()
	eyes_mesh.size = Vector3(0.42, 0.1, 0.08)
	var eyes := _visual_mesh("Glowing Eyes", eyes_mesh, Color(1.0, 0.8, 0.28))
	eyes.position = Vector3(0, 0.12, -0.43)
	enemy.add_child(eyes)
	var collision := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.75
	collision.shape = shape
	enemy.add_child(collision)
	enemy.body_entered.connect(_on_enemy_body_entered.bind(enemy))
	world_root.add_child(enemy)
	enemies.append(enemy)

func _on_enemy_body_entered(body: Node3D, enemy: Node3D) -> void:
	if body == player and invulnerable <= 0.0:
		_take_hit(15)

func _spawn_boss() -> void:
	boss_active = true
	boss_max_hp = 10 + int(level / 10) * 2
	boss_hp = boss_max_hp
	boss = Node3D.new()
	boss.name = "Frost Titan"
	boss.position = Vector3(0, 1.4, -15)
	var body_mesh := SphereMesh.new()
	body_mesh.radius = 1.65
	body_mesh.height = 3.2
	var body := _visual_mesh("Titan Armor", body_mesh, Color(0.12, 0.28, 0.58))
	boss.add_child(body)
	var chest_mesh := SphereMesh.new()
	chest_mesh.radius = 0.58
	var chest := _visual_mesh("Glowing Ice Core", chest_mesh, Color(0.1, 0.88, 1.0))
	chest.position = Vector3(0, 0.1, -1.2)
	boss.add_child(chest)
	for side in [-1.0, 1.0]:
		var horn_mesh := PrismMesh.new()
		horn_mesh.size = Vector3(0.65, 1.15, 0.6)
		var horn := _visual_mesh("Ice Horn", horn_mesh, Color(0.7, 0.94, 1.0))
		horn.position = Vector3(side * 1.15, 1.5, 0)
		boss.add_child(horn)
	world_root.add_child(boss)
	message_label.text = "BOSS LEVEL %d! Hit the Titan with ICE and BLAST!" % level

func _attack(special: bool) -> void:
	if game_over or not is_instance_valid(player):
		return
	if special:
		if special_cooldown > 0.0:
			message_label.text = "BLAST recharging: %.1fs" % special_cooldown
			return
		special_cooldown = 3.5
	else:
		if attack_cooldown > 0.0:
			return
		attack_cooldown = 0.45
	_spawn_projectile(special)
	var attack_range := 10.0 if special else 3.8
	for enemy in enemies.duplicate():
		if is_instance_valid(enemy) and absf(enemy.global_position.z - player.global_position.z) < attack_range and absf(enemy.global_position.x - player.global_position.x) < 2.7:
			enemies.erase(enemy)
			enemy.queue_free()
			coins += 2
	if boss_active and is_instance_valid(boss):
		var in_range := absf(boss.global_position.z - player.global_position.z) < attack_range + 2.0 and absf(boss.global_position.x - player.global_position.x) < 4.0
		if in_range:
			boss_hp = maxi(0, boss_hp - (3 if special else 1))
			message_label.text = "ICE HIT! TITAN HP: %d / %d" % [boss_hp, boss_max_hp]
			if boss_hp == 0:
				boss.queue_free()
				boss_active = false
				boss = null
				coins += 50
				message_label.text = "TITAN DEFEATED! +50 COINS — reach the gate or tap NEXT"
	_update_hud()

func _spawn_projectile(special: bool) -> void:
	var mesh := SphereMesh.new()
	mesh.radius = 0.28 if special else 0.18
	var projectile := _visual_mesh("Ice Blast", mesh, Color(0.1, 0.85, 1.0) if special else Color(0.65, 0.96, 1.0))
	projectile.position = player.global_position + Vector3(0, 1.0, -0.8)
	add_child(projectile)
	var tween := create_tween()
	tween.tween_property(projectile, "position:z", projectile.position.z - (11.0 if special else 4.0), 0.32)
	tween.tween_callback(projectile.queue_free)

func _take_hit(amount: int) -> void:
	if invulnerable > 0.0 or game_over:
		return
	invulnerable = 1.2
	health -= amount
	if health <= 0:
		lives -= 1
		health = 100
		if lives <= 0:
			game_over = true
			message_label.text = "GAME OVER — tap NEXT to restart"
		else:
			message_label.text = "Ouch! Respawning — lives left: %d" % lives
			if is_instance_valid(player):
				player.position = Vector3(0, 1.2, 8)
				player.velocity = Vector3.ZERO
	_update_hud()

func _complete_level() -> void:
	if level % 10 == 0 and boss_active:
		message_label.text = "Defeat the Frost Titan first!"
		return
	if level >= MAX_LEVEL:
		message_label.text = "LEGEND COMPLETE! 200 LEVELS CLEARED!"
		return
	level += 1
	lives = 3
	health = 100
	game_over = false
	attack_cooldown = 0.0
	special_cooldown = 0.0
	save_progress()
	_clear_world()
	_build_world()
	if is_instance_valid(player):
		player.queue_free()
	_build_player()
	message_label.text = "WORLD %d — LEVEL %d" % [int((level - 1) / 10) + 1, level]
	_update_hud()

func _clear_world() -> void:
	if is_instance_valid(world_root):
		world_root.queue_free()
	world_root = null
	enemies.clear()
	coins_in_world.clear()
	boss = null
	boss_active = false

func _toggle_pause() -> void:
	game_over = not game_over
	message_label.text = "PAUSED" if game_over else "LET'S GO!"

func _world_color() -> Color:
	match int((level - 1) / 10) % 4:
		0: return Color(0.48, 0.78, 0.91)
		1: return Color(0.32, 0.64, 0.84)
		2: return Color(0.57, 0.72, 0.91)
		_: return Color(0.28, 0.51, 0.72)

func _update_hud() -> void:
	if not is_instance_valid(level_label):
		return
	level_label.text = "PENGUIN LEGENDS 3D  |  LEVEL %03d" % level
	stats_label.text = "♥ %d/%d     ◈ %d     LIVES %d" % [health, 100, coins, lives]
	if boss_active:
		boss_label.text = "FROST TITAN: %d / %d HP" % [boss_hp, boss_max_hp]
	else:
		boss_label.text = "TILT TO MOVE  •  JUMP  •  ICE  •  BLAST"

func save_progress() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("progress", "level", level)
	cfg.set_value("progress", "coins", coins)
	cfg.save(SAVE_PATH)

func load_progress() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) == OK:
		level = clampi(int(cfg.get_value("progress", "level", 1)), 1, MAX_LEVEL)
		coins = maxi(0, int(cfg.get_value("progress", "coins", 0)))
