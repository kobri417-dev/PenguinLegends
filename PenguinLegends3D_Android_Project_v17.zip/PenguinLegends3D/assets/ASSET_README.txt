PENGUIN LEGENDS 3D — CUSTOM ASSET PACK

Created for the Godot 4.3 project:
- models/kobra_penguin_hero.glb: custom multi-part hero penguin with layered feathers, scarf, backpack, crown, glowing eyes and orange feet.
- models/ice_castle_detailed.glb: custom ice fortress with towers, spires, glowing windows, buttresses and snow caps.
- models/ice_shards.glb: reusable shard cluster for the KOBRATIX intro.
- textures/handpainted_ice_albedo.png: hand-painted procedural icy surface texture.

These are original procedural meshes, not downloaded or copied commercial assets. Import GLB files in Godot 4.3. The asset pack is a first detailed asset pass; scene placement, scale, lighting and Android performance still need to be checked in Godot and on a phone.
