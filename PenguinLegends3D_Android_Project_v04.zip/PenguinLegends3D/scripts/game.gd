extends Node3D

const SAVE_PATH := "user://penguin_legends_save.cfg"
var level := 1
var coins := 0
var lives := 3
var player: CharacterBody3D
var boss: Node3D
var boss_health := 5
var boss_active := false
var attack_cooldown := 0.0
var invulnerable := 0.0
var hud: CanvasLayer
var level_label: Label
var coin_label: Label
var lives_label: Label
var message_label: Label
var tilt_value := 0.0
var paused_game := false
var mobile := false

func _ready() -> void:
	mobile = OS.has_feature("android") or OS.has_feature("ios")
	load_progress()
	_build_world()
	_build_player()
	_build_hud()
	_update_hud()

func _process(delta: float) -> void:
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	invulnerable = maxf(0.0, invulnerable - delta)
	if player and not paused_game:
		var gravity := float(ProjectSettings.get_setting("physics/3d/default_gravity"))
		if not player.is_on_floor(): player.velocity.y -= gravity * delta
		var axis := Input.get_axis("move_left", "move_right")
		if mobile:
			var accel := Input.get_accelerometer()
			if accel.length() > 0.1: tilt_value = clampf(accel.x * 1.8, -1.0, 1.0)
			axis = tilt_value if absf(tilt_value) > 0.08 else axis
		player.velocity.x = move_toward(player.velocity.x, axis * 6.0, 18.0 * delta)
		player.velocity.z = move_toward(player.velocity.z, -2.2, 8.0 * delta)
		if Input.is_action_just_pressed("jump") and player.is_on_floor(): player.velocity.y = 7.0
		if Input.is_action_just_pressed("attack"): _attack()
		player.move_and_slide()
		if player.global_position.y < -8.0: _lose_life()
		if boss_active and is_instance_valid(boss): _boss_update(delta)

func _build_world() -> void:
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_SKY
	e.sky = Sky.new()
	e.sky.sky_material = ProceduralSkyMaterial.new()
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.65, 0.8, 1.0)
	e.ambient_light_energy = 0.8
	env.environment = e
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -25, 0)
	sun.light_energy = 1.25
	add_child(sun)
	_make_box("Ice Island", Vector3(0, -0.6, 0), Vector3(24, 1.2, 30), Color(0.25, 0.75, 0.92))
	for i in range(12):
		var x := randf_range(-9, 9)
		var z := randf_range(-12, 12)
		_make_coin(Vector3(x, 0.6, z))
	for i in range(4):
		_make_enemy(Vector3(randf_range(-8, 8), 0.5, randf_range(-9, 8)))
	if level % 10 == 0: _spawn_boss()
	else: _make_box("Ice Gate", Vector3(0, 0.6, -13), Vector3(3, 2, 0.6), Color(0.6, 0.95, 1.0))
	var camera := Camera3D.new()
	camera.position = Vector3(0, 9, 13)
	camera.rotation_degrees = Vector3(-28, 0, 0)
	camera.current = true
	add_child(camera)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Penguin"
	player.position = Vector3(0, 1, 8)
	var body := MeshInstance3D.new()
	var mesh := CapsuleMesh.new()
	mesh.radius = 0.48
	mesh.height = 1.35
	body.mesh = mesh
	body.material_override = _mat(Color(0.06, 0.12, 0.2))
	player.add_child(body)
	var belly := MeshInstance3D.new()
	var bm := SphereMesh.new()
	bm.radius = 0.32
	bm.height = 0.65
	belly.mesh = bm
	belly.position = Vector3(0, -0.05, -0.31)
	belly.material_override = _mat(Color(0.94, 0.97, 1.0))
	player.add_child(belly)
	for side in [-1.0, 1.0]:
		var eye := MeshInstance3D.new()
		var em := SphereMesh.new()
		em.radius = 0.07
		eye.mesh = em
		eye.position = Vector3(side * 0.16, 0.25, -0.43)
		eye.material_override = _mat(Color(0.02, 0.02, 0.03))
		player.add_child(eye)
	var beak := MeshInstance3D.new()
	var cone := PrismMesh.new()
	cone.size = Vector3(0.25, 0.16, 0.2)
	beak.mesh = cone
	beak.position = Vector3(0, 0.04, -0.52)
	beak.material_override = _mat(Color(1.0, 0.55, 0.08))
	player.add_child(beak)
	var collision := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.45
	shape.height = 1.35
	collision.shape = shape
	player.add_child(collision)
	add_child(player)

func _build_hud() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	var panel := PanelContainer.new()
	panel.position = Vector2(16, 14)
	panel.custom_minimum_size = Vector2(280, 110)
	hud.add_child(panel)
	var v := VBoxContainer.new()
	panel.add_child(v)
	level_label = Label.new(); v.add_child(level_label)
	coin_label = Label.new(); v.add_child(coin_label)
	lives_label = Label.new(); v.add_child(lives_label)
	message_label = Label.new()
	message_label.position = Vector2(350, 22)
	message_label.add_theme_font_size_override("font_size", 26)
	hud.add_child(message_label)
	_add_button("JUMP", Vector2(-180, -150), Vector2(130, 70), func(): if player and player.is_on_floor(): player.velocity.y = 7.0)
	_add_button("ATTACK", Vector2(-325, -150), Vector2(130, 70), func(): _attack())
	_add_button("PAUSE", Vector2(-115, 20), Vector2(95, 50), func(): _toggle_pause())
	_add_button("NEXT LEVEL", Vector2(16, 135), Vector2(150, 52), func(): _next_level())

func _add_button(caption: String, offset: Vector2, size: Vector2, action: Callable) -> void:
	var b := Button.new()
	b.text = caption
	b.custom_minimum_size = size
	b.anchor_left = 1.0 if offset.x < 0 else 0.0
	b.anchor_right = 1.0 if offset.x < 0 else 0.0
	b.anchor_top = 1.0 if offset.y < 0 else 0.0
	b.anchor_bottom = 1.0 if offset.y < 0 else 0.0
	b.position = offset if offset.x >= 0 and offset.y >= 0 else offset
	b.pressed.connect(action)
	hud.add_child(b)

func _make_box(label: String, pos: Vector3, size: Vector3, color: Color) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = label
	body.position = pos
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new(); box.size = size
	mesh.mesh = box; mesh.material_override = _mat(color)
	body.add_child(mesh)
	var cs := CollisionShape3D.new(); var shape := BoxShape3D.new(); shape.size = size
	cs.shape = shape; body.add_child(cs)
	add_child(body)
	return body

func _make_coin(pos: Vector3) -> void:
	var coin := Area3D.new(); coin.name = "Coin"; coin.position = pos
	var m := MeshInstance3D.new(); var sm := SphereMesh.new(); sm.radius = 0.22; sm.height = 0.44
	m.mesh = sm; m.material_override = _mat(Color(1.0, 0.75, 0.08)); coin.add_child(m)
	var c := CollisionShape3D.new(); var s := SphereShape3D.new(); s.radius = 0.6; c.shape = s; coin.add_child(c)
	coin.body_entered.connect(func(body): if body == player: coins += 1; _update_hud(); coin.queue_free())
	add_child(coin)

func _make_enemy(pos: Vector3) -> void:
	var enemy := Area3D.new(); enemy.name = "Snow Grunt"; enemy.position = pos
	var m := MeshInstance3D.new(); var sm := SphereMesh.new(); sm.radius = 0.48; sm.height = 0.9
	m.mesh = sm; m.material_override = _mat(Color(0.7, 0.15, 0.2)); enemy.add_child(m)
	var c := CollisionShape3D.new(); var s := SphereShape3D.new(); s.radius = 0.65; c.shape = s; enemy.add_child(c)
	enemy.body_entered.connect(func(body): if body == player and invulnerable <= 0: _lose_life())
	add_child(enemy)

func _spawn_boss() -> void:
	boss_active = true; boss_health = 5
	boss = Node3D.new(); boss.name = "Frost Titan"; boss.position = Vector3(0, 1.6, -7)
	var m := MeshInstance3D.new(); var sm := SphereMesh.new(); sm.radius = 1.45; sm.height = 2.8
	m.mesh = sm; m.material_override = _mat(Color(0.25, 0.45, 0.95)); boss.add_child(m)
	var c := CollisionShape3D.new(); var s := SphereShape3D.new(); s.radius = 1.6; c.shape = s; boss.add_child(c)
	add_child(boss)
	message_label.text = "BOSS LEVEL! Frost Titan — 5 hits to win!"

func _boss_update(delta: float) -> void:
	if not is_instance_valid(boss): return
	boss.position.x = sin(Time.get_ticks_msec() / 700.0) * 3.0
	if randf() < delta * 0.28 and player.global_position.distance_to(boss.global_position) < 7.0 and invulnerable <= 0: _lose_life()

func _attack() -> void:
	if attack_cooldown > 0: return
	attack_cooldown = 0.65
	if boss_active and is_instance_valid(boss) and player.global_position.distance_to(boss.global_position) < 5.0:
		boss_health -= 1
		message_label.text = "Ice strike! Boss HP: %d" % boss_health
		if boss_health <= 0:
			boss.queue_free(); boss_active = false
			message_label.text = "BOSS DEFEATED! Tap NEXT LEVEL"
	else:
		message_label.text = "ICE BURST!"

func _lose_life() -> void:
	lives -= 1; invulnerable = 1.5; _update_hud()
	if lives <= 0:
		message_label.text = "GAME OVER — tap NEXT LEVEL to retry"
		paused_game = true
	else:
		player.global_position = Vector3(0, 1, 8)

func _next_level() -> void:
	level += 1; lives = 3; paused_game = false; save_progress()
	for child in get_children():
		if child != hud: child.queue_free()
	_build_world(); _build_player(); _update_hud()
	message_label.text = "WORLD %d — Level %d" % [int((level - 1) / 10) + 1, level]

func _toggle_pause() -> void:
	paused_game = not paused_game
	message_label.text = "PAUSED" if paused_game else "LET'S GO!"

func _update_hud() -> void:
	if level_label: level_label.text = "🐧 Penguin Legends 3D  |  Level %d" % level
	if coin_label: coin_label.text = "Coins: %d" % coins
	if lives_label: lives_label.text = "Lives: %d" % lives

func save_progress() -> void:
	var cfg := ConfigFile.new(); cfg.set_value("progress", "level", level); cfg.set_value("progress", "coins", coins); cfg.save(SAVE_PATH)

func load_progress() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) == OK:
		level = int(cfg.get_value("progress", "level", 1)); coins = int(cfg.get_value("progress", "coins", 0))

func _mat(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new(); m.albedo_color = color; m.roughness = 0.7; return m
