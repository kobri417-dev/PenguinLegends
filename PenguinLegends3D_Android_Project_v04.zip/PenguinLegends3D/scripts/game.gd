extends Node3D

# Penguin Legends 3D — Android-friendly procedural adventure prototype.
# Godot 4.3 / GL Compatibility. No external assets or plugins required.

const SAVE_PATH := "user://penguin_legends_save.cfg"
const MAX_LEVEL := 200
const GRAVITY := 20.0

var level := 1
var coins := 0
var lives := 3
var health := 100
var player: CharacterBody3D
var camera: Camera3D
var world_root: Node3D
var hud: CanvasLayer
var level_label: Label
var stats_label: Label
var message_label: Label
var boss_label: Label
var jump_requested := false
var attack_requested := false
var special_requested := false
var tilt_axis := 0.0
var attack_cooldown := 0.0
var special_cooldown := 0.0
var invulnerable := 0.0
var boss: Node3D
var boss_hp := 0
var boss_max_hp := 0
var boss_active := false
var game_over := false
var elapsed := 0.0
var enemies: Array[Node3D] = []
var coins_in_world: Array[Area3D] = []
var mobile := false
var menu_layer: CanvasLayer
var menu_root: Control
var music_player: AudioStreamPlayer
var intro_player: AudioStreamPlayer
var selected_penguin := 0
var music_enabled := true
var menu_open := true
var penguin_colors := [Color(0.025, 0.055, 0.095), Color(0.12, 0.35, 0.78), Color(0.35, 0.10, 0.48)]
var penguin_names := ["KOBRA CLASSIC", "ARCTIC GUARDIAN", "SHADOW LEGEND"]

func _ready() -> void:
	mobile = OS.has_feature("android") or OS.has_feature("ios")
	load_progress()
	_setup_audio()
	_build_menu_background()
	_show_intro()
	_build_main_menu()

func _setup_audio() -> void:
\tmusic_player = AudioStreamPlayer.new()
\tmusic_player.name = "BackgroundMusic"
\tmusic_player.volume_db = -15.0
\tmusic_player.stream = _make_music_stream()
\tadd_child(music_player)
\tintro_player = AudioStreamPlayer.new()
\tintro_player.name = "KobratixIntroAudio"
\tintro_player.volume_db = -8.0
\tintro_player.stream = _make_intro_stream()
\tadd_child(intro_player)
\tmusic_player.play()

func _make_music_stream() -> AudioStreamWAV:
\t# Original procedural chiptune-style ambient loop; no external files needed.
\tvar rate := 22050
\tvar seconds := 8.0
\tvar bytes := PackedByteArray()
\tvar frames := int(rate * seconds)
\tfor i in range(frames):
\t\tvar t := float(i) / float(rate)
\t\tvar beat := int(t * 2.0) % 4
\t\tvar roots := [110.0, 130.81, 146.83, 98.0]
\t\tvar root: float = roots[int(t / 2.0) % roots.size()]
\t\tvar bass := sin(TAU * root * t) * 0.20
\t\tvar pad := sin(TAU * root * 2.0 * t) * 0.10 + sin(TAU * root * 3.0 * t) * 0.045
\t\tvar note := 0.0
\t\tif beat == 0 or beat == 2:
\t\t\tnote = sin(TAU * root * 4.0 * t) * 0.06
\t\tvar fade := minf(1.0, t * 8.0) * minf(1.0, (seconds - t) * 8.0)
\t\tvar sample := int(clampf((bass + pad + note) * fade, -0.9, 0.9) * 32767.0)
\t\tbytes.append(sample & 0xff)
\t\tbytes.append((sample >> 8) & 0xff)
\tvar stream := AudioStreamWAV.new()
\tstream.format = AudioStreamWAV.FORMAT_16_BITS
\tstream.mix_rate = rate
\tstream.stereo = false
\tstream.loop_mode = AudioStreamWAV.LOOP_FORWARD
\tstream.loop_begin = 0
\tstream.loop_end = frames
\tstream.data = bytes
\treturn stream

func _make_intro_stream() -> AudioStreamWAV:
\t# Short synthesized rising fanfare for the creator splash.
\tvar rate := 22050
\tvar seconds := 1.7
\tvar bytes := PackedByteArray()
\tvar frames := int(rate * seconds)
\tfor i in range(frames):
\t\tvar t := float(i) / float(rate)
\t\tvar freq := 330.0 + 330.0 * (t / seconds)
\t\tvar env := minf(1.0, t * 12.0) * maxf(0.0, 1.0 - t / seconds)
\t\tvar sample := int(clampf(sin(TAU * freq * t) * env * 0.45, -0.9, 0.9) * 32767.0)
\t\tbytes.append(sample & 0xff)
\t\tbytes.append((sample >> 8) & 0xff)
\tvar stream := AudioStreamWAV.new()
\tstream.format = AudioStreamWAV.FORMAT_16_BITS
\tstream.mix_rate = rate
\tstream.stereo = false
\tstream.data = bytes
\treturn stream

func _build_menu_background() -> void:
\t_build_world()
\t# Scenic ice crystals, aurora pillars and reflective-looking ice.
\tfor i in range(18):
\t\tvar h := randf_range(2.0, 6.0)
\t\tvar crystal := _make_visual_box("Aurora Crystal", Vector3(randf_range(-13.0, 13.0), h * 0.5, randf_range(-22.0, 12.0)), Vector3(0.35, h, 0.35), [Color(0.12, 0.75, 1.0), Color(0.32, 0.45, 1.0), Color(0.62, 0.85, 1.0)][i % 3])
\t\tcrystal.rotation_degrees.z = randf_range(-12.0, 12.0)
\t\tworld_root.add_child(crystal)
\tif not is_instance_valid(camera):
\t\tcamera = Camera3D.new()
\t\tcamera.name = "MenuCamera"
\t\tcamera.current = true
\t\tcamera.fov = 64.0
\t\tadd_child(camera)
\tcamera.position = Vector3(0, 6.2, 17.0)
\tcamera.look_at(Vector3(0, 1.2, -3.0), Vector3.UP)
\t# Showcase penguin visible behind the menu.
\t_build_player()
\tplayer.position = Vector3(3.8, 1.2, 1.0)

func _show_intro() -> void:
\tvar splash := CanvasLayer.new()
\tsplash.name = "KobratixSplash"
\tadd_child(splash)
\tvar shade := ColorRect.new()
\tshade.color = Color(0.008, 0.025, 0.075, 1.0)
\tshade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
\tsplash.add_child(shade)
\tvar title := Label.new()
\ttitle.text = "CREATED BY"
\ttitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
\ttitle.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
\ttitle.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
\ttitle.add_theme_font_size_override("font_size", 30)
\ttitle.add_theme_color_override("font_color", Color(0.64, 0.9, 1.0))
\tsplash.add_child(title)
\tvar creator := Label.new()
\tcreator.text = "KOBRATIX"
\tcreator.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
\tcreator.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
\tcreator.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
\tcreator.add_theme_font_size_override("font_size", 64)
\tcreator.add_theme_color_override("font_color", Color(1.0, 0.78, 0.18))
\tcreator.scale = Vector2(0.55, 0.55)
\tsplash.add_child(creator)
\tif is_instance_valid(intro_player): intro_player.play()
\tvar tween := create_tween()
\ttween.tween_property(creator, "scale", Vector2.ONE, 0.65).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
\ttween.parallel().tween_property(creator, "modulate", Color.WHITE, 0.55)
\ttween.tween_interval(1.1)
\ttween.tween_property(shade, "modulate:a", 0.0, 0.45)
\ttween.tween_callback(splash.queue_free)

func _build_main_menu() -> void:
\tmenu_open = true
\tmenu_layer = CanvasLayer.new()
\tmenu_layer.name = "MainMenu"
\tadd_child(menu_layer)
\tmenu_root = Control.new()
\tmenu_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
\tmenu_layer.add_child(menu_root)
\tvar dim := ColorRect.new()
\tdim.color = Color(0.005, 0.025, 0.065, 0.62)
\tdim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
\tmenu_root.add_child(dim)
\tvar title := Label.new()
\ttitle.text = "PENGUIN  LEGENDS 3D"
\ttitle.position = Vector2(24, 28)
\ttitle.size = Vector2(900, 72)
\ttitle.add_theme_font_size_override("font_size", 42)
\ttitle.add_theme_color_override("font_color", Color(0.64, 0.93, 1.0))
\tmenu_root.add_child(title)
\tvar subtitle := Label.new()
\tsubtitle.text = "RISE OF THE FROST LEGENDS"
\tsubtitle.position = Vector2(30, 91)
\tsubtitle.add_theme_font_size_override("font_size", 17)
\tsubtitle.add_theme_color_override("font_color", Color(1.0, 0.79, 0.24))
\tmenu_root.add_child(subtitle)
\tvar card := PanelContainer.new()
\tcard.position = Vector2(28, 145)
\tcard.custom_minimum_size = Vector2(370, 475)
\tvar panel_style := StyleBoxFlat.new()
\tpanel_style.bg_color = Color(0.015, 0.07, 0.14, 0.94)
\tpanel_style.border_color = Color(0.18, 0.75, 1.0, 0.9)
\tpanel_style.set_border_width_all(2)
\tpanel_style.set_corner_radius_all(22)
\tpanel_style.content_margin_left = 20
\tpanel_style.content_margin_right = 20
\tpanel_style.content_margin_top = 18
\tpanel_style.content_margin_bottom = 18
\tcard.add_theme_stylebox_override("panel", panel_style)
\tmenu_root.add_child(card)
\tvar stack := VBoxContainer.new()
\tstack.add_theme_constant_override("separation", 12)
\tcard.add_child(stack)
\tvar choose := Label.new()
\tchoose.text = "CHOOSE YOUR PENGUIN"
\tchoose.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
\tchoose.add_theme_font_size_override("font_size", 20)
\tstack.add_child(choose)
\tvar penguin_picker := OptionButton.new()
\tfor name in penguin_names: penguin_picker.add_item(name)
\tpenguin_picker.selected = selected_penguin
\tpenguin_picker.item_selected.connect(_select_penguin)
\tstack.add_child(penguin_picker)
\tvar start := _menu_button("✦   NEW GAME", Color(0.02, 0.48, 0.72))
\tstart.pressed.connect(_start_game)
\tstack.add_child(start)
\tvar settings := _menu_button("⚙   SETTINGS", Color(0.08, 0.25, 0.42))
\tsettings.pressed.connect(_show_settings)
\tstack.add_child(settings)
\tvar continue_button := _menu_button("CONTINUE ADVENTURE", Color(0.08, 0.25, 0.42))
\tcontinue_button.pressed.connect(_continue_game)
\tstack.add_child(continue_button)
\tvar note := Label.new()
\tnote.text = "200 LEVELS  •  20 BOSSES  •  ICE POWERS"
\tnote.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
\tnote.add_theme_font_size_override("font_size", 13)
\tnote.add_theme_color_override("font_color", Color(0.62, 0.84, 1.0))
\tstack.add_child(note)
\tvar footer := Label.new()
\tfooter.text = "CREATED BY KOBRATIX"
\tfooter.position = Vector2(25, 650)
\tfooter.size = Vector2(700, 36)
\tfooter.add_theme_font_size_override("font_size", 19)
\tfooter.add_theme_color_override("font_color", Color(1.0, 0.78, 0.2))
\tmenu_root.add_child(footer)
\tvar footer_tween := create_tween().set_loops()
\tfooter_tween.tween_property(footer, "modulate", Color(0.5, 0.9, 1.0), 1.0)
\tfooter_tween.tween_property(footer, "modulate", Color.WHITE, 1.0)

func _menu_button(caption: String, color: Color) -> Button:
\tvar button := Button.new()
\tbutton.text = caption
\tbutton.custom_minimum_size = Vector2(0, 58)
\tbutton.add_theme_font_size_override("font_size", 20)
\tvar style := StyleBoxFlat.new()
\tstyle.bg_color = color
\tstyle.border_color = Color(0.35, 0.88, 1.0)
\tstyle.set_border_width_all(1)
\tstyle.set_corner_radius_all(14)
\tbutton.add_theme_stylebox_override("normal", style)
\tvar hover := style.duplicate()
\thover.bg_color = color.lightened(0.18)
\tbutton.add_theme_stylebox_override("hover", hover)
\treturn button

func _select_penguin(index: int) -> void:
\tselected_penguin = clampi(index, 0, penguin_colors.size() - 1)
\tif is_instance_valid(player):
\t\tvar body := player.get_node_or_null("Penguin Body/Visual")
\t\t# Rebuild showcase hero so all color pieces match the selected skin.
\t\tplayer.queue_free()
\t\t_build_player()
\t\tplayer.position = Vector3(3.8, 1.2, 1.0)

func _start_game() -> void:
\t_begin_game(1)

func _continue_game() -> void:
\t_begin_game(level)

func _begin_game(start_level: int) -> void:
\tif is_instance_valid(menu_layer): menu_layer.queue_free()
\tmenu_open = false
\tlevel = clampi(start_level, 1, MAX_LEVEL)
\t_clear_world()
\t_build_world()
\tif is_instance_valid(player): player.queue_free()
\t_build_player()
\t_build_hud()
\t_update_hud()

func _show_settings() -> void:
\tvar dialog := AcceptDialog.new()
\tdialog.title = "SETTINGS"
\tdialog.dialog_text = "Music: %s\\nSoundtrack and intro audio are generated locally.\\nControls: tilt phone to move; use on-screen JUMP, ICE and BLAST buttons." % ("ON" if music_enabled else "OFF")
\tmenu_root.add_child(dialog)
\tdialog.add_button("TOGGLE MUSIC", true, "toggle_music")
\tdialog.confirmed.connect(func(): pass)
\tdialog.custom_action.connect(func(action: String):
\t\tif action == "toggle_music":
\t\t\tmusic_enabled = not music_enabled
\t\t\tif music_enabled: music_player.play()
\t\t\telse: music_player.stop()
\t)
\tdialog.popup_centered(Vector2i(560, 260))

func _process(delta: float) -> void:
	elapsed += delta
	if menu_open:
		if is_instance_valid(player): player.rotate_y(delta * 0.25)
		return
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	special_cooldown = maxf(0.0, special_cooldown - delta)
	invulnerable = maxf(0.0, invulnerable - delta)
	if mobile:
		var accel := Input.get_accelerometer()
		if accel.length() > 0.12:
			tilt_axis = clampf(accel.x * 1.6, -1.0, 1.0)
	for coin in coins_in_world:
		if is_instance_valid(coin):
			coin.rotate_y(delta * 2.0)
			coin.position.y = 0.8 + sin(elapsed * 2.4 + coin.position.z) * 0.12
	for enemy in enemies:
		if is_instance_valid(enemy):
			enemy.position.x = enemy.get_meta("home_x", 0.0) + sin(elapsed * 1.4 + enemy.position.z) * 1.4
	if boss_active and is_instance_valid(boss):
		boss.position.x = sin(elapsed * 0.9) * 2.8
		if player and player.global_position.distance_to(boss.global_position) < 3.2 and invulnerable <= 0.0:
			_take_hit(12)
	_update_hud()

func _physics_process(delta: float) -> void:
	if menu_open or not is_instance_valid(player) or game_over:
		return
	var axis := Input.get_axis("move_left", "move_right")
	if mobile and absf(tilt_axis) > 0.08:
		axis = tilt_axis
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		axis = -1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		axis = 1.0
	player.velocity.x = move_toward(player.velocity.x, axis * 7.0, 22.0 * delta)
	player.velocity.z = move_toward(player.velocity.z, -3.0, 8.0 * delta)
	if not player.is_on_floor():
		player.velocity.y -= GRAVITY * delta
	elif jump_requested or Input.is_action_just_pressed("jump") or Input.is_key_pressed(KEY_SPACE):
		player.velocity.y = 8.0
	jump_requested = false
	player.move_and_slide()
	player.position.x = clampf(player.position.x, -10.0, 10.0)
	if player.position.y < -5.0:
		_take_hit(25)
		player.position = Vector3(0, 1.2, 8)
		player.velocity = Vector3.ZERO
	if attack_requested:
		_attack(false)
		attack_requested = false
	if special_requested:
		_attack(true)
		special_requested = false
	if player.position.z < -22.0:
		_complete_level()

func _build_world() -> void:
	world_root = Node3D.new()
	world_root.name = "LevelWorld"
	add_child(world_root)
	var env_node := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color(0.025, 0.09, 0.23)
	sky_material.sky_horizon_color = Color(0.28, 0.62, 0.82)
	sky_material.ground_bottom_color = Color(0.04, 0.1, 0.18)
	sky_material.ground_horizon_color = Color(0.55, 0.78, 0.9)
	sky.sky_material = sky_material
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.58, 0.72, 0.88)
	environment.ambient_light_energy = 0.85
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.glow_enabled = true
	environment.glow_intensity = 0.7
	env_node.environment = environment
	world_root.add_child(env_node)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -28, 0)
	sun.light_energy = 1.35
	sun.shadow_enabled = true
	world_root.add_child(sun)

	var floor := _make_box("Glacier Path", Vector3(0, -0.5, 0), Vector3(23, 1, 60), _world_color())
	world_root.add_child(floor)
	for side in [-1.0, 1.0]:
		for i in range(7):
			var peak_height := 5.0 + float((i + level) % 5) * 1.4
			var peak := _make_visual_box("Ice Cliff", Vector3(3.0, peak_height, 4.0), Color(0.12, 0.34, 0.55))
			peak.position = Vector3(side * (13.0 + float(i % 2)), peak_height * 0.35, -20.0 + float(i) * 6.0)
			world_root.add_child(peak)
	for i in range(6):
		var z := 3.0 - float(i) * 4.0
		var side_x := -5.0 if i % 2 == 0 else 5.0
		var platform := _make_box("Floating Ice Platform", Vector3(side_x, 0.65, z), Vector3(3.0, 0.45, 2.8), Color(0.65, 0.9, 1.0))
		world_root.add_child(platform)
	for i in range(15):
		var pos := Vector3(randf_range(-8.0, 8.0), 0.9, randf_range(-20.0, 18.0))
		_make_coin(pos)
	for i in range(4 + int(level / 8)):
		_make_enemy(Vector3(randf_range(-7.0, 7.0), 0.5, randf_range(-18.0, 10.0)))
	if level % 10 == 0:
		_spawn_boss()
	else:
		var gate := _make_visual_box("Glacier Gate", Vector3(0, 1.3, -23.0), Vector3(5.0, 2.8, 0.6), Color(0.1, 0.55, 0.78))
		world_root.add_child(gate)
	# Reuse a single camera; attach it to the root for stable Android rendering.
	if not is_instance_valid(camera):
		camera = Camera3D.new()
		camera.name = "AdventureCamera"
		camera.current = true
		camera.fov = 72.0
		add_child(camera)
	camera.position = Vector3(0, 8.5, 15.5)
	camera.rotation_degrees = Vector3(-25, 0, 0)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "PenguinHero"
	player.position = Vector3(0, 1.2, 8)
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.46
	capsule.height = 1.45
	collision.shape = capsule
	collision.position.y = 0.75
	player.add_child(collision)
	var body := _visual_mesh("Penguin Body", CapsuleMesh.new(), penguin_colors[selected_penguin])
	body.position.y = 0.75
	player.add_child(body)
	var belly_mesh := SphereMesh.new()
	belly_mesh.radius = 0.34
	belly_mesh.height = 0.76
	var belly := _visual_mesh("Snow White Belly", belly_mesh, Color(0.93, 0.97, 1.0))
	belly.position = Vector3(0, 0.72, -0.31)
	player.add_child(belly)
	var head_mesh := SphereMesh.new()
	head_mesh.radius = 0.38
	head_mesh.height = 0.7
	var head := _visual_mesh("Penguin Head", head_mesh, penguin_colors[selected_penguin])
	head.position = Vector3(0, 1.42, -0.03)
	player.add_child(head)
	for side in [-1.0, 1.0]:
		var eye_mesh := SphereMesh.new()
		eye_mesh.radius = 0.075
		var eye := _visual_mesh("Eye", eye_mesh, Color.WHITE)
		eye.position = Vector3(side * 0.15, 1.48, -0.36)
		player.add_child(eye)
		var pupil_mesh := SphereMesh.new()
		pupil_mesh.radius = 0.035
		var pupil := _visual_mesh("Pupil", pupil_mesh, Color(0.015, 0.02, 0.03))
		pupil.position = Vector3(side * 0.15, 1.48, -0.42)
		player.add_child(pupil)
	var beak_mesh := PrismMesh.new()
	beak_mesh.size = Vector3(0.24, 0.14, 0.22)
	var beak := _visual_mesh("Orange Beak", beak_mesh, Color(1.0, 0.43, 0.035))
	beak.position = Vector3(0, 1.32, -0.45)
	player.add_child(beak)
	for side in [-1.0, 1.0]:
		var flipper_mesh := BoxMesh.new()
		flipper_mesh.size = Vector3(0.2, 0.68, 0.28)
		var flipper := _visual_mesh("Flipper", flipper_mesh, penguin_colors[selected_penguin])
		flipper.position = Vector3(side * 0.53, 0.78, 0.0)
		flipper.rotation.z = side * -0.18
		player.add_child(flipper)
		var foot_mesh := BoxMesh.new()
		foot_mesh.size = Vector3(0.34, 0.12, 0.38)
		var foot := _visual_mesh("Orange Foot", foot_mesh, Color(1.0, 0.35, 0.025))
		foot.position = Vector3(side * 0.22, 0.12, -0.17)
		player.add_child(foot)
	add_child(player)

func _build_hud() -> void:
	hud = CanvasLayer.new()
	hud.name = "GameHUD"
	add_child(hud)
	var panel := PanelContainer.new()
	panel.position = Vector2(14, 14)
	panel.custom_minimum_size = Vector2(330, 104)
	hud.add_child(panel)
	var stack := VBoxContainer.new()
	panel.add_child(stack)
	level_label = Label.new()
	level_label.add_theme_font_size_override("font_size", 21)
	stack.add_child(level_label)
	stats_label = Label.new()
	stats_label.add_theme_font_size_override("font_size", 17)
	stack.add_child(stats_label)
	boss_label = Label.new()
	boss_label.add_theme_color_override("font_color", Color(0.2, 0.85, 1.0))
	stack.add_child(boss_label)
	message_label = Label.new()
	message_label.anchor_left = 0.2
	message_label.anchor_right = 0.8
	message_label.anchor_top = 0.0
	message_label.anchor_bottom = 0.0
	message_label.offset_top = 125
	message_label.offset_bottom = 170
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.add_theme_font_size_override("font_size", 23)
	message_label.add_theme_color_override("font_color", Color(1.0, 0.86, 0.35))
	hud.add_child(message_label)
	_add_button("JUMP", Vector2(-112, -108), Vector2(96, 82), func(): jump_requested = true)
	_add_button("ICE", Vector2(-220, -92), Vector2(90, 72), func(): attack_requested = true)
	_add_button("BLAST", Vector2(-115, -198), Vector2(100, 72), func(): special_requested = true)
	_add_button("NEXT", Vector2(14, 130), Vector2(100, 52), func(): _complete_level())
	_add_button("PAUSE", Vector2(-105, 14), Vector2(92, 48), func(): _toggle_pause())

func _add_button(caption: String, offset: Vector2, size: Vector2, action: Callable) -> void:
	var button := Button.new()
	button.text = caption
	button.custom_minimum_size = size
	if offset.x < 0:
		button.anchor_left = 1.0
		button.anchor_right = 1.0
	else:
		button.anchor_left = 0.0
		button.anchor_right = 0.0
	if offset.y < 0:
		button.anchor_top = 1.0
		button.anchor_bottom = 1.0
	else:
		button.anchor_top = 0.0
		button.anchor_bottom = 0.0
	button.position = offset
	button.add_theme_font_size_override("font_size", 18)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.025, 0.28, 0.48, 0.92)
	style.border_color = Color(0.25, 0.82, 1.0)
	style.set_border_width_all(2)
	style.set_corner_radius_all(15)
	button.add_theme_stylebox_override("normal", style)
	button.pressed.connect(action)
	hud.add_child(button)

func _make_box(label: String, pos: Vector3, size: Vector3, color: Color) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = label
	body.position = pos
	var mesh := BoxMesh.new()
	mesh.size = size
	var visual := _visual_mesh(label + " Visual", mesh, color)
	body.add_child(visual)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)
	return body

func _make_visual_box(label: String, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	var visual := _visual_mesh(label, mesh, color)
	visual.position = pos
	return visual

func _visual_mesh(label: String, mesh: Mesh, color: Color) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.name = label
	instance.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.68
	instance.material_override = material
	return instance

func _make_coin(pos: Vector3) -> void:
	var coin := Area3D.new()
	coin.name = "Golden Ice Coin"
	coin.position = pos
	var mesh := SphereMesh.new()
	mesh.radius = 0.23
	mesh.height = 0.46
	var visual := _visual_mesh("Gold", mesh, Color(1.0, 0.68, 0.04))
	coin.add_child(visual)
	var material := visual.material_override as StandardMaterial3D
	material.metallic = 0.55
	material.emission_enabled = true
	material.emission = Color(0.35, 0.15, 0.0)
	var collision := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.72
	collision.shape = shape
	coin.add_child(collision)
	coin.body_entered.connect(_on_coin_body_entered.bind(coin))
	world_root.add_child(coin)
	coins_in_world.append(coin)

func _on_coin_body_entered(body: Node3D, coin: Area3D) -> void:
	if body == player and is_instance_valid(coin):
		coins += 1
		coins_in_world.erase(coin)
		coin.queue_free()
		_update_hud()

func _make_enemy(pos: Vector3) -> void:
	var enemy := Area3D.new()
	enemy.name = "Snow Creature"
	enemy.position = pos
	enemy.set_meta("home_x", pos.x)
	var mesh := SphereMesh.new()
	mesh.radius = 0.5
	mesh.height = 0.95
	var visual := _visual_mesh("Creature Body", mesh, Color(0.55, 0.13, 0.22))
	enemy.add_child(visual)
	var eyes_mesh := BoxMesh.new()
	eyes_mesh.size = Vector3(0.42, 0.1, 0.08)
	var eyes := _visual_mesh("Glowing Eyes", eyes_mesh, Color(1.0, 0.8, 0.28))
	eyes.position = Vector3(0, 0.12, -0.43)
	enemy.add_child(eyes)
	var collision := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.75
	collision.shape = shape
	enemy.add_child(collision)
	enemy.body_entered.connect(_on_enemy_body_entered.bind(enemy))
	world_root.add_child(enemy)
	enemies.append(enemy)

func _on_enemy_body_entered(body: Node3D, enemy: Node3D) -> void:
	if body == player and invulnerable <= 0.0:
		_take_hit(15)

func _spawn_boss() -> void:
	boss_active = true
	boss_max_hp = 10 + int(level / 10) * 2
	boss_hp = boss_max_hp
	boss = Node3D.new()
	boss.name = "Frost Titan"
	boss.position = Vector3(0, 1.4, -15)
	var body_mesh := SphereMesh.new()
	body_mesh.radius = 1.65
	body_mesh.height = 3.2
	var body := _visual_mesh("Titan Armor", body_mesh, Color(0.12, 0.28, 0.58))
	boss.add_child(body)
	var chest_mesh := SphereMesh.new()
	chest_mesh.radius = 0.58
	var chest := _visual_mesh("Glowing Ice Core", chest_mesh, Color(0.1, 0.88, 1.0))
	chest.position = Vector3(0, 0.1, -1.2)
	boss.add_child(chest)
	for side in [-1.0, 1.0]:
		var horn_mesh := PrismMesh.new()
		horn_mesh.size = Vector3(0.65, 1.15, 0.6)
		var horn := _visual_mesh("Ice Horn", horn_mesh, Color(0.7, 0.94, 1.0))
		horn.position = Vector3(side * 1.15, 1.5, 0)
		boss.add_child(horn)
	world_root.add_child(boss)
	message_label.text = "BOSS LEVEL %d! Hit the Titan with ICE and BLAST!" % level

func _attack(special: bool) -> void:
	if game_over or not is_instance_valid(player):
		return
	if special:
		if special_cooldown > 0.0:
			message_label.text = "BLAST recharging: %.1fs" % special_cooldown
			return
		special_cooldown = 3.5
	else:
		if attack_cooldown > 0.0:
			return
		attack_cooldown = 0.45
	_spawn_projectile(special)
	var attack_range := 10.0 if special else 3.8
	for enemy in enemies.duplicate():
		if is_instance_valid(enemy) and absf(enemy.global_position.z - player.global_position.z) < attack_range and absf(enemy.global_position.x - player.global_position.x) < 2.7:
			enemies.erase(enemy)
			enemy.queue_free()
			coins += 2
	if boss_active and is_instance_valid(boss):
		var in_range := absf(boss.global_position.z - player.global_position.z) < attack_range + 2.0 and absf(boss.global_position.x - player.global_position.x) < 4.0
		if in_range:
			boss_hp = maxi(0, boss_hp - (3 if special else 1))
			message_label.text = "ICE HIT! TITAN HP: %d / %d" % [boss_hp, boss_max_hp]
			if boss_hp == 0:
				boss.queue_free()
				boss_active = false
				boss = null
				coins += 50
				message_label.text = "TITAN DEFEATED! +50 COINS — reach the gate or tap NEXT"
	_update_hud()

func _spawn_projectile(special: bool) -> void:
	var mesh := SphereMesh.new()
	mesh.radius = 0.28 if special else 0.18
	var projectile := _visual_mesh("Ice Blast", mesh, Color(0.1, 0.85, 1.0) if special else Color(0.65, 0.96, 1.0))
	projectile.position = player.global_position + Vector3(0, 1.0, -0.8)
	add_child(projectile)
	var tween := create_tween()
	tween.tween_property(projectile, "position:z", projectile.position.z - (11.0 if special else 4.0), 0.32)
	tween.tween_callback(projectile.queue_free)

func _take_hit(amount: int) -> void:
	if invulnerable > 0.0 or game_over:
		return
	invulnerable = 1.2
	health -= amount
	if health <= 0:
		lives -= 1
		health = 100
		if lives <= 0:
			game_over = true
			message_label.text = "GAME OVER — tap NEXT to restart"
		else:
			message_label.text = "Ouch! Respawning — lives left: %d" % lives
			if is_instance_valid(player):
				player.position = Vector3(0, 1.2, 8)
				player.velocity = Vector3.ZERO
	_update_hud()

func _complete_level() -> void:
	if level % 10 == 0 and boss_active:
		message_label.text = "Defeat the Frost Titan first!"
		return
	if level >= MAX_LEVEL:
		message_label.text = "LEGEND COMPLETE! 200 LEVELS CLEARED!"
		return
	level += 1
	lives = 3
	health = 100
	game_over = false
	attack_cooldown = 0.0
	special_cooldown = 0.0
	save_progress()
	_clear_world()
	_build_world()
	if is_instance_valid(player):
		player.queue_free()
	_build_player()
	message_label.text = "WORLD %d — LEVEL %d" % [int((level - 1) / 10) + 1, level]
	_update_hud()

func _clear_world() -> void:
	if is_instance_valid(world_root):
		world_root.queue_free()
	world_root = null
	enemies.clear()
	coins_in_world.clear()
	boss = null
	boss_active = false

func _toggle_pause() -> void:
	game_over = not game_over
	message_label.text = "PAUSED" if game_over else "LET'S GO!"

func _world_color() -> Color:
	match int((level - 1) / 10) % 4:
		0: return Color(0.48, 0.78, 0.91)
		1: return Color(0.32, 0.64, 0.84)
		2: return Color(0.57, 0.72, 0.91)
		_: return Color(0.28, 0.51, 0.72)

func _update_hud() -> void:
	if not is_instance_valid(level_label):
		return
	level_label.text = "PENGUIN LEGENDS 3D  |  LEVEL %03d" % level
	stats_label.text = "♥ %d/%d     ◈ %d     LIVES %d" % [health, 100, coins, lives]
	if boss_active:
		boss_label.text = "FROST TITAN: %d / %d HP" % [boss_hp, boss_max_hp]
	else:
		boss_label.text = "TILT TO MOVE  •  JUMP  •  ICE  •  BLAST"

func save_progress() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("progress", "level", level)
	cfg.set_value("progress", "coins", coins)
	cfg.save(SAVE_PATH)

func load_progress() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) == OK:
		level = clampi(int(cfg.get_value("progress", "level", 1)), 1, MAX_LEVEL)
		coins = maxi(0, int(cfg.get_value("progress", "coins", 0)))
