PENGUIN LEGENDS 3D — Android/Godot project prototype

This is a Godot 4 source project, not a compiled APK.

Open:
  project.godot
in Godot 4.3 or newer.

Controls:
- Keyboard: A/D move, Space jump, F attack.
- Touch buttons: Jump, Attack, Pause, Next Level.
- Android tilt movement is read from the accelerometer.
- Boss encounter on every level divisible by 10.

To export an APK:
1. Install Godot 4.x and matching export templates.
2. Install Android SDK, platform tools, build-tools and JDK as required by Godot.
3. In Godot: Project > Export > Add Android preset.
4. Configure Android SDK paths under Editor Settings > Export > Android.
5. Export a debug APK and install it on your phone.

Prototype note: this project has not been run or compiled in this environment. Review and test scripts in Godot before release. Some touch layout and gameplay balancing may need adjustment on-device.
