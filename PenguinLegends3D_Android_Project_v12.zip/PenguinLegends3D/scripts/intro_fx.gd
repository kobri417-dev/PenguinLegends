extends Control

# Procedural neon rings and drifting ice-energy particles for the creator splash.
var elapsed := 0.0
var particles: Array[Dictionary] = []

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    var rng := RandomNumberGenerator.new()
    rng.randomize()
    for i in range(74):
        particles.append({
            "x": rng.randf(),
            "y": rng.randf(),
            "speed": rng.randf_range(0.025, 0.12),
            "size": rng.randf_range(1.0, 3.2),
            "phase": rng.randf_range(0.0, TAU),
            "alpha": rng.randf_range(0.25, 0.95)
        })

func _process(delta: float) -> void:
    elapsed += delta
    for p in particles:
        p["y"] = fposmod(float(p["y"]) - float(p["speed"]) * delta, 1.0)
        p["x"] = fposmod(float(p["x"]) + sin(elapsed * 0.8 + float(p["phase"])) * delta * 0.025, 1.0)
    queue_redraw()

func _draw() -> void:
    var s := size
    if s.x <= 0.0 or s.y <= 0.0:
        return
    var c := Vector2(s.x * 0.5, s.y * 0.5)
    var base := minf(s.x, s.y) * 0.31
    # Several glowing orbit rings, offset to create a cinematic 3D illusion.
    for ring in range(3):
        var radius := base + float(ring) * 13.0 + sin(elapsed * 1.8 + float(ring)) * 3.0
        var points := PackedVector2Array()
        for i in range(101):
            var a := TAU * float(i) / 100.0 + elapsed * (0.55 if ring % 2 == 0 else -0.42)
            var x_scale := 1.0 if ring == 0 else 0.88
            var y_scale := 0.20 if ring == 0 else (0.34 if ring == 1 else 0.12)
            points.append(c + Vector2(cos(a) * radius * x_scale, sin(a) * radius * y_scale))
        var col := Color(0.0, 0.62 + 0.1 * float(ring), 1.0, 0.46 if ring == 0 else 0.27)
        draw_polyline(points, Color(col.r, col.g, col.b, 0.13), 8.0, true)
        draw_polyline(points, col, 1.8 if ring == 0 else 1.2, true)
    # Light beams behind the wordmark.
    for beam in range(9):
        var y := c.y + sin(elapsed * 1.4 + float(beam)) * s.y * 0.19
        var x0 := s.x * 0.08
        var x1 := s.x * 0.92
        draw_line(Vector2(x0, y), Vector2(x1, y), Color(0.0, 0.48, 1.0, 0.035), 1.0)
    # Floating blue-white energy particles.
    for p in particles:
        var px := float(p["x"]) * s.x
        var py := float(p["y"]) * s.y
        var pulse := 0.55 + 0.45 * sin(elapsed * 3.0 + float(p["phase"]))
        var alpha := float(p["alpha"]) * pulse
        var col := Color(0.15, 0.72 + pulse * 0.25, 1.0, alpha)
        var r := float(p["size"])
        draw_circle(Vector2(px, py), r * 2.5, Color(0.0, 0.55, 1.0, alpha * 0.12))
        draw_circle(Vector2(px, py), r, col)
    # Small bright energy core.
    var glow_alpha := 0.12 + 0.08 * (sin(elapsed * 2.5) + 1.0)
    draw_circle(c, base * 0.68, Color(0.0, 0.35, 0.95, glow_alpha * 0.08))
