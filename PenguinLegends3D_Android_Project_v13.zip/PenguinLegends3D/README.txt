Penguin Legends 3D — Android Godot project
Version v09: redesigned main menu with cinematic icy-blue title, glowing PLAY / SETTINGS / CONTINUE buttons, animated title/footer, character selection, and procedural distant frost castle and snowy mountain scenery. Includes the KOBRATIX neon intro from v08.
Engine: Godot 4.3, GL Compatibility. No external assets required.

Import project.godot in Godot 4.3. Android export requires the Godot Android export templates and Android SDK/JDK configured.
The archive was structurally checked but has not been compiled or device-tested in this environment.

Version v10: intro uses the four approved reference panels in order with fade transitions and slow cinematic zoom. Display changed to landscape to preserve the reference compositions.

Version v11: replaced flat intro reference frames with a procedural 3D intro built from Godot 3D meshes, animated neon torus rings, metallic 3D KOBRATIX text, 3D ice shards, lighting, camera push-in, and animated fade-out. This is a real-time 3D scene, not a video or a set of flat screenshots.

Version v12: replaced flat intro frames with a procedural real-time 3D intro: animated neon 3D torus rings, metallic 3D KOBRATIX lettering, flying 3D ice shards, camera push-in, then 3D PENGUIN LEGENDS 3D title/loading sequence. Added live GPU snowfall and animated wind-swaying snow-covered pine trees to the 3D main menu environment.

Version v13: fixed the Godot 4.3 GDScript type-inference parse error for tower_h by declaring it as float.
