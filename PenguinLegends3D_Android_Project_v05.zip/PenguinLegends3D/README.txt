PENGUIN LEGENDS 3D — KOBRATIX EDITION
Godot 4.3 project. Main scene: res://scenes/Main.tscn

Features in this build:
- Animated CREATED BY KOBRATIX splash and synthesized intro fanfare
- Main menu: New Game, Settings, Continue Adventure
- Three selectable penguin skins
- Procedural looping background soundtrack (no external audio assets)
- Procedural 3D ice world, glow lighting, platforms, coins, enemies and boss encounters
- On-screen jump, ice attack, blast, next-level and pause controls
- Android tilt movement with keyboard fallback

Android export workflow expected ZIP filename: PenguinLegends3D_Android_Project_v04.zip
Godot version: 4.3
