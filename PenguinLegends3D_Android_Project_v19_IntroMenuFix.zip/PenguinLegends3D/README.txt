PENGUIN LEGENDS 3D — Android Godot 4.3 project (v18 intro reliability fix)

Includes the six-stage procedural 3D splash, portrait menu scene, snowfall, swaying pine scenery, custom GLB penguin and ice-castle assets, shard cluster, and hand-painted glacial albedo/roughness maps.

New visual assets:
- assets/textures/ice_pbr_albedo.png — 1024x1024 glacial veins and ice flecks
- assets/textures/ice_roughness.png — 1024x1024 roughness detail map
- assets/models/kobra_penguin_hero.glb
- assets/models/ice_castle_detailed.glb
- assets/models/ice_shards.glb

Status: this is an improved development build, NOT a verified finished commercial-quality game. It has not been compiled with Godot or tested on a physical Android device here. The procedural scene is a custom stylized interpretation, not a pixel-identical reproduction of the reference image. Import in Godot 4.3 and verify scene framing, materials, animation and Android performance before release.
\n\nv18 fix: added a full-screen animated KOBRATIX / PENGUIN LEGENDS 3D overlay using the existing procedural rings and particles. The intro is now visible independently of 3D Label3D framing on portrait Android screens. Please import and export with Godot 4.3 to test on-device.\n